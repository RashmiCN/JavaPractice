package com.heb.payroll.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.heb.payroll.servlet.PayrollException;

public class SkillDao {
	
	
	public void insertSkill(int skillId)throws PayrollException{
		Connection connection = ConnectionManager.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement("delete from skill where sk_id = ?");
			statement.setInt(1, skillId);	
			int i = statement.executeUpdate();
		
		}catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("Error when getting all employees",e);
		} finally {
			try {
				if(statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("error while closing the connections" ,e);
			}
		}
	}//end of insert skill
	
	public void deleteSkill(int skillId)throws PayrollException {
		Connection connection = ConnectionManager.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement("delete from skill where sk_id = ?");
			statement.setInt(1, skillId);	
			int i = statement.executeUpdate();
		
		}catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("Error when getting all employees",e);
		} finally {
			try {
				if(statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("error while closing the connections" ,e);
			}
		}	
	}//end of method
}//end of class
