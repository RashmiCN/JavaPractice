package com.heb.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.heb.payroll.servlet.PayrollException;
import com.heb.taxcalculator.model.Address;

public class AddressDao {

	
	private static final String UPDATE_ADR_QUERY = 
			"update address" +
			"SET ad_address_line_1 = ? " +
			"ad_address_line_2 = ? " +
			"ad_locality = ? " +
			"ad_city= ? " +
			"ad_pincode = ? " +
			"WHERE ad_ID = ?";
			;
			
	public AddressDao() {
		// TODO Auto-generated constructor stub
	}
	
	public void updateAdress(Address address,int addressId) throws PayrollException {			
		Connection connection = ConnectionManager.getConnection();
		PreparedStatement statement = null;

		try {
			statement = connection.prepareStatement(UPDATE_ADR_QUERY);
			statement.setString(1,address.getAddressLine1());
			statement.setString(2,address.getAddressLine2());
			statement.setString(3,address.getLocality());
			statement.setString(4,address.getCity());
			statement.setString(5, address.getPincode());
			statement.setInt(6, addressId);
			statement.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("Error when getting all employees",e);
		} finally {
		try {
			if(statement != null) {
			   statement.close();
			}
			if (connection != null) {
				connection.close();
			}
		} catch(SQLException e) {
				e.printStackTrace();
				throw new PayrollException("error while closing the connections" ,e);
		}

		}//end of updateEmployee
	}//end of method
}//end of class
