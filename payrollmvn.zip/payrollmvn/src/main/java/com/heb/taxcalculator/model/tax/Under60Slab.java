	package com.heb.taxcalculator.model.tax;
	
	public class Under60Slab extends AbstractIncomeTaxPay1{
		
		private static Slab[] UNDER_60_TAX_SLABS = {

			new Slab(0.0, 250000.0,0),
			new Slab(250000.0,500000.0,0.05),
			new Slab(500000.0,1000000.0,0.2),
			new Slab(1000000.0,Double.MAX_VALUE,0.3)
		};
		
		public Under60Slab(double annualIncome){
			super(annualIncome);
			this.taxSlabs = UNDER_60_TAX_SLABS ;
		}
		
	}