package com.heb.taxcalculator.model.tax;

public abstract class AbstractIncomeTaxPay1{
		
		protected double annualIncome;
		protected Slab[] taxSlabs ;
	
		public AbstractIncomeTaxPay1(double annualIncome) {
				
			this.annualIncome = annualIncome ;
		}
			
		public double calculateTax(){
			
			double totalTax = 0.0;
			for (Slab taxSlab : taxSlabs){
				
				totalTax +=  taxSlab.calculateTax(annualIncome);
			}
			
			return totalTax ;

}

}