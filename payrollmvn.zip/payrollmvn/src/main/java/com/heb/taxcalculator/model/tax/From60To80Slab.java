	package com.heb.taxcalculator.model.tax;
	
	public class From60To80Slab extends AbstractIncomeTaxPay1{
		
		private static Slab[] FROM_60_TO_80_SLABS = {

			new Slab(0.0, 300000.0,0),
			new Slab(300000.0,500000.0,0.05),
			new Slab(500000.0,1000000.0,0.2),
			new Slab(1000000.0,Double.MAX_VALUE,0.3)
		};
		
		public From60To80Slab(double annualIncome){
			super(annualIncome);
			this.taxSlabs = FROM_60_TO_80_SLABS ;
		}
		
	}