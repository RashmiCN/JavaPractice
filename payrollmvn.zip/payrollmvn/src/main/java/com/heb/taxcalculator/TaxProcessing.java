package com.heb.taxcalculator;

import com.heb.taxcalculator.model.Employee;
import com.heb.taxcalculator.dao.TaxCalculatorCsvFileReader;
import com.heb.taxcalculator.model.tax.AbstractIncomeTaxPay1;
import com.heb.taxcalculator.model.tax.Under60Slab;
import com.heb.taxcalculator.model.tax.From60To80Slab;
import com.heb.taxcalculator.model.tax.Above80Slab;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class TaxProcessing {
	
	public static void main(String args[]){
		
		TaxProcessing processor =  new TaxProcessing();
		try {
		processor.processTax();
		} catch (InterruptedException e) {
			e.printStackTrace();

		}
	}
	
	public void processTax() throws InterruptedException{
		long startTime=System.nanoTime();
		TaxCalculatorCsvFileReader read = new TaxCalculatorCsvFileReader();
		List<Employee> employees = new ArrayList<Employee>();
		ExecutorService executor = Executors.newFixedThreadPool(100);
		employees = read.readAll("D:/employee.csv");
		List<TaxCalculatorThread> threads = new ArrayList<TaxCalculatorThread>();
		
		for (Employee employee : employees) {
			int age = employee.getAge();
			double salary = employee.getSalary();
			AbstractIncomeTaxPay1 taxcalc = null;
			if(age <= 60) {
				taxcalc = new Under60Slab(salary);
			} else if(age > 60 && age <= 80) {
				taxcalc = new From60To80Slab(salary);
			} else if (age > 80) {	
				taxcalc = new Above80Slab(salary);
			}
			TaxCalculatorThread thread = new TaxCalculatorThread(taxcalc,employee);
			executor.execute(thread);
		}
		executor.shutdown();
		while (!executor.isTerminated()) {
		}
		for (TaxCalculatorThread thread : threads){
			thread.join();			
		}
		for(Employee emp : employees){
			System.out.println(emp);
		}
		long duration = System.nanoTime()-startTime;
		System.out.println(duration*0.000000001);
		}
	}	



