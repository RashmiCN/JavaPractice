package com.heb.taxcalculator.model.tax;
class Slab{
	
		private double slabAmount ;
		
		private double percentage ;
		
		private double startRange;
		
		private double endRange;
		
//		private float incomeAmt;


		public Slab(double startRange,double endRange,double percentage){
			this.startRange = startRange;
			this.percentage = percentage;
			this.endRange = endRange;
			
		}
		
		public double calculateTax(double incomeAmt){
						
			if(incomeAmt > endRange){
				slabAmount = endRange - startRange ;
			}
			
			if (incomeAmt >= startRange && incomeAmt < endRange){
						slabAmount = incomeAmt - startRange;
				}
			
			return (slabAmount * percentage) ;
			
		}
}
	
	