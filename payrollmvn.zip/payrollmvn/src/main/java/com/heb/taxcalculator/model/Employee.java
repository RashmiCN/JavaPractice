// Class for the employee details
package com.heb.taxcalculator.model;

import java.util.ArrayList;

import java.util.List;

import java.util.Collections;
import java.util.Date;




public class Employee implements Comparable<Object>{

//Declarations for the class
	private int id;
	private int age;			
	private String name;
	private Date dateofBirth;
	private double salary;
	private String email;
	private Address address;
	private double taxAmount;
	private String skills;
	private String gender;
	private String departmentName;
	
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDateofBirth() {
		return dateofBirth;
	}
	public void setDateofBirth(Date dateofBirth) {
		this.dateofBirth = dateofBirth;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public double getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}



// constructor to initialize the id,age and string name

//	Employee(int id,int age,String name){
	public Employee (){
		
	}
	public Employee (String employeeData){
		
		String[] data = employeeData.split(",");
		this.id = Integer.parseInt(data[0]);
		this.name = data[1];
		this.age=Integer.parseInt(data[2]);
		this.salary = Integer.parseInt(data[3]);
		this.email = data[4];
		this.address = new Address(data);
	}
	public Employee(int id, String name , int age,double salary){
		this.id=id;
		this.name = name;
		this.age=age;
		this.salary=salary;
	}
	
	
	public void display() {
			
		System.out.println(address);
	}
	
	public boolean equals(Object object) {
		
		System.out.println("equals");
	
		if(this == object) {
		   return true ;
		}
		
		if (object instanceof Employee) {
			Employee employee = (Employee) object ;
			return employee.getId() == this.id;
		}
		
		return false;
	}
	
	public int hashCode() {
		System.out.println("hashcode");
		int hashCode = (new Integer(id)).hashCode();
		System.out.println(hashCode);
		return hashCode;
	
	}
	
	public int compareTo(Object e) {
		Employee e1 = (Employee) e;
		if(this.id > e1.getId()) {
			return 1;
		}
		
		if (id < e1.getId()) {
			return -1 ;
		}
		
		return 0;
		
	
	}
	
// Overloading the toString()  method to return the required values
	
	public String toString(){
		StringBuilder builder = new StringBuilder();
		builder.append("Id = ");
		builder.append(id);
		builder.append(";");
		builder.append("Name = ");
		builder.append(name);
		builder.append(";");
		builder.append("Age = ");
		builder.append(age);
		builder.append(";");
		builder.append("Salary = ");
		builder.append(salary);
		builder.append(";");
		builder.append("Tax Amount =");
		builder.append(taxAmount);
		builder.append(";");
		builder.append(address);
		return builder.toString();
	}
	
	public static void main(String args[]) {
		Employee e1 = new Employee(1,"Thiru",25,250000f);
		Employee e2 = new Employee(3,"Aravind",25,250000f);
		Employee e3 = new Employee(2,"Santhosh",25,250000f);
		
//		ArrayList<Employee> employees = new ArrayList<Employee>();

		List<Employee> employees = new ArrayList<Employee>();
		
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
//		Collections.sort(employees);		
		Collections.sort(employees ,new EmployeeNameComparator());
		
//		System.out.println(e1.compareTo(e2));
//		System.out.println(e3.compareTo(e2));
//		System.out.println(e3.compareTo(e3));
		
				
		
		for(Object employee : employees) {
			System.out.println(employee);
		}
	}
}
	