import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DataFileReader {

	
public  List<TrainDetailsVO> readfile(String filePath){
		
		BufferedReader reader = null;
		
		List<TrainDetailsVO> train = new ArrayList<TrainDetailsVO>();
		
		try {
		reader = new BufferedReader(new FileReader(filePath));
		String line = reader.readLine();
		while(line != null){
			TrainDetailsVO e = new TrainDetailsVO();
			String[] data = line.split(",");
			e.setTrainNumber(data[0]);
			e.setRoute(data[1]);
			e.setSource(Integer.parseInt(data[2]));
			e.setDestination(Integer.parseInt(data[3]));
			e.setSpecial(data[4].charAt(0));
			train.add(e);
			line = reader.readLine();
			} 
		}catch(IOException exception) {	
			exception.printStackTrace();
		}finally{
		if(reader != null){
			try{
				reader.close();
			} catch (IOException e){
				e.printStackTrace();
			}
		}
	
		}
		
		return train; 
	}
}
