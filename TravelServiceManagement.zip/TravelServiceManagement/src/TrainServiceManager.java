import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import java.util.TreeSet;

public class TrainServiceManager {
	
	
	/* Return the list of trains for the given parameter */
	public List<TrainDetailsVO> getTrainDetails(final String filePath, int source,
			int destination, String dateOfTravel)
			throws TrainServiceException {
		
			List<TrainDetailsVO> train = new ArrayList<TrainDetailsVO>();
			List<TrainDetailsVO> train1 = new ArrayList<TrainDetailsVO>();
			
			DataFileReader read1 =  new DataFileReader();
			train = read1.readfile(filePath);
			
			SimpleDateFormat format1=new SimpleDateFormat("yyyy/mm/dd");
			  Date dt1=format1.parse(dateOfTravel);
			  DateFormat format2=new SimpleDateFormat("EEEE"); 
			  String finalDay=format2.format(dt1);  
			  System.out.println(finalDay);
			  for(TrainDetailsVO trains : train) {
				if(trains.getDestination() == destination && trains.getSource() == source){
						if(finalDay.equals("Sunday")){
							if(trains.getSpecial() == 'Y')
								train1.add(trains);
						}else {
							 	train1.add(trains);
						}
								
					}
						
				}
			return train1;			
			
		}
	
	   public static void main(String args[]) throws TrainServiceException{
		   
		   TrainServiceManager t1 = new TrainServiceManager();
		   
		   t1.getTrainDetails("D:/TrainDetails.csv",01,10,"2018/08/14");
	   }
	
}

