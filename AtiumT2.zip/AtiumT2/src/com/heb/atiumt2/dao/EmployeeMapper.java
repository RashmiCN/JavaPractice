package com.heb.atiumt2.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.heb.atiumt2.model.Address;
import com.heb.atiumt2.model.Employee;

public class EmployeeMapper implements RowMapper<Employee> {

	public Employee mapRow(ResultSet resultSet, int i) throws SQLException {

		Employee employee = new Employee();
		employee.setId(resultSet.getInt("EM_ID"));
		employee.setName(resultSet.getString("EM_NAME"));
		employee.setDateOfBirth(resultSet.getDate("EM_DATE_OF_BIRTH"));
		employee.setGender(resultSet.getString("EM_GENDER"));
		employee.setSalary(resultSet.getInt("EM_SALARY"));
		employee.setEmail(resultSet.getString("EM_EMAIL"));
		employee.setDepartmentId(resultSet.getInt("DP_ID"));
		employee.setDepartmentName(resultSet.getString("DP_NAME"));
		employee.setSkills(resultSet.getString("SKILLS"));
		Address address = new Address();
		address.setId(resultSet.getInt("AD_ID"));
		address.setAddressLine1(resultSet.getString("AD_ADDRESS_LINE_1"));
		address.setAddressLine2(resultSet.getString("AD_ADDRESS_LINE_2"));
		address.setLocality(resultSet.getString("AD_LOCALITY"));
		address.setCity(resultSet.getString("AD_CITY"));
		address.setPinCode(resultSet.getInt("AD_PINCODE"));
		employee.setAddress(address);
		return employee;
	}
}
