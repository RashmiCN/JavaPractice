package com.heb.atiumt2.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.heb.atiumt2.model.Skill;

@Component
public class SkillDao {
	
	private static final String GET_ALL_SKILLS = "select * from skill";

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public SkillDao(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public List<Skill> getAllSkills() {
		return jdbcTemplate.query(GET_ALL_SKILLS, new SkillMapper());
	}
}
