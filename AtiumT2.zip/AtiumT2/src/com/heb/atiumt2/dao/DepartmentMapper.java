package com.heb.atiumt2.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.heb.atiumt2.model.Department;

public class DepartmentMapper implements RowMapper<Department> {

	public Department mapRow(ResultSet resultSet, int i) throws SQLException {
		Department department = new Department();
		department.setId(resultSet.getInt("DP_ID"));
		department.setName(resultSet.getString("DP_NAME"));
		return department;
	}
}
