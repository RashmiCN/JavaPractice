package com.heb.atiumt2.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.heb.atiumt2.model.Address;

@Component
public class AddressDao {
	
	private static final String UPDATE_ADDRESS_SQL = "Update ADDRESS set ad_address_line_1 = ?, ad_address_line_2 = ?, " +
			"ad_locality = ?, ad_city = ?, ad_pincode = ? where ad_id = ?";

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public AddressDao(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public boolean updateAddress(Address address) {
		return jdbcTemplate.update(
				UPDATE_ADDRESS_SQL,
				address.getAddressLine1(),
				address.getAddressLine2(),
				address.getLocality(),
				address.getCity(),
				address.getPinCode(),
				address.getId()
			) > 0;
	}
}
