package com.heb.atiumt2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.heb.atiumt2.exception.PayrollException;
import com.heb.atiumt2.model.Address;
import com.heb.atiumt2.model.Department;
import com.heb.atiumt2.model.Employee;
import com.heb.atiumt2.model.Skill;

@Component
public class OldEmployeeDao {
	
	private static final String GET_ALL_EMP_QUERY = 
		"	  select em_id, em_name, em_date_of_birth, em_gender, em_salary," + 
		"            em_email, dp_name, ad_id, ad_address_line_1, ad_address_line_2, ad_locality," + 
		"            ad_city, ad_pincode, listagg(sk_name, ', ') within group (order by sk_name) skills" +
		"    from employee, department, address, skill, employee_skill " +
		"   where em_ad_id = ad_id " + 
		"     and em_dp_id = dp_id " + 
		"     and em_id = es_em_id " + 
		"     and sk_id = es_sk_id " + 
		"group by em_id, em_name, em_date_of_birth, em_gender, em_salary, " + 
		"         em_email, dp_name, ad_id, ad_address_line_1, ad_address_line_2, ad_locality, " + 
		"         ad_city, ad_pincode";
	
	private static final String UPDATE_EMPLOYEE_SQL = "Update EMPLOYEE set em_name = ?, em_date_of_birth = ?, " +
		"em_gender = ?, em_salary = ?, em_email = ?, em_dp_id = ? where em_id = ?";

	private static final String UPDATE_ADDRESS_SQL = "Update ADDRESS set ad_address_line_1 = ?, ad_address_line_2 = ?, " +
			"ad_locality = ?, ad_city = ?, ad_pincode = ? where ad_id = ?";

	private static final String GET_EMP_QUERY = 
			"	  select em_id, em_name, em_date_of_birth, em_gender, em_salary," + 
			"            em_email, dp_id, dp_name, ad_address_line_1, ad_address_line_2, ad_locality," + 
			"            ad_city, ad_pincode, listagg(sk_name, ', ') within group (order by sk_name) skills" +
			"    from employee, department, address, skill, employee_skill " +
			"   where em_id = ? " + 
			"     and em_ad_id = ad_id " + 
			"     and em_dp_id = dp_id " + 
			"     and em_id = es_em_id " + 
			"     and sk_id = es_sk_id " + 
			"group by em_id, em_name, em_date_of_birth, em_gender, em_salary, " + 
			"         em_email, dp_id, dp_name, ad_address_line_1, ad_address_line_2, ad_locality, " + 
			"         ad_city, ad_pincode";
	
	private DataSource dataSource;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {	
		System.out.println("inside setDataSource()");
		this.dataSource = dataSource;
	}
	
	public List<Employee> getAllEmployees() throws PayrollException {
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<Employee> employees = new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(GET_ALL_EMP_QUERY);
			while (resultSet.next()) {
				Employee employee = new Employee();
				employee.setId(resultSet.getInt("EM_ID"));
				employee.setName(resultSet.getString("EM_NAME"));
				employee.setDateOfBirth(resultSet.getDate("EM_DATE_OF_BIRTH"));
				employee.setGender(resultSet.getString("EM_GENDER"));
				employee.setSalary(resultSet.getInt("EM_SALARY"));
				employee.setEmail(resultSet.getString("EM_EMAIL"));
				employee.setDepartmentName(resultSet.getString("DP_NAME"));
				employee.setSkills(resultSet.getString("SKILLS"));
				Address address = new Address();
				address.setId(resultSet.getInt("AD_ID"));
				address.setAddressLine1(resultSet.getString("AD_ADDRESS_LINE_1"));
				address.setAddressLine2(resultSet.getString("AD_ADDRESS_LINE_2"));
				address.setLocality(resultSet.getString("AD_LOCALITY"));
				address.setCity(resultSet.getString("AD_CITY"));
				address.setPinCode(resultSet.getInt("AD_PINCODE"));
				employee.setAddress(address);
				employees.add(employee);
			}
		} catch (SQLException exception) {
			exception.printStackTrace();
			throw new PayrollException("Error when getting all employees", exception);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException exception) {
				throw new PayrollException("Error when getting all employees", exception);
			}
		}
		return employees;
	}
	
	public List<Department> getAllDepartments() throws PayrollException {
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<Department> departments = new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery("select * from department");
			while (resultSet.next()) {
				Department department = new Department();
				department.setId(resultSet.getInt("DP_ID"));
				department.setName(resultSet.getString("DP_NAME"));
				departments.add(department);
			}
		} catch (SQLException exception) {
			exception.printStackTrace();
			throw new PayrollException("Error when getting all departments", exception);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException exception) {
				throw new PayrollException("Error when getting all departments", exception);
			}
		}
 		return departments;
	}

	public List<Skill> getAllSkills() throws PayrollException {
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<Skill> skills = new ArrayList<>();
		try {
			connection = dataSource.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery("select * from skill");
			while (resultSet.next()) {
				Skill skill = new Skill();
				skill.setId(resultSet.getInt("SK_ID"));
				skill.setName(resultSet.getString("SK_NAME"));
				skills.add(skill);
			}
		} catch (SQLException exception) {
			exception.printStackTrace();
			throw new PayrollException("Error when getting all skills", exception);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException exception) {
				throw new PayrollException("Error when getting all departments", exception);
			}
		}
 		return skills;
	}
	
	public Employee getEmployee(int id) throws PayrollException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Employee employee = null;
		try {
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(GET_EMP_QUERY);
			statement.setInt(1, id);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				employee = new Employee();
				employee.setId(resultSet.getInt("EM_ID"));
				employee.setName(resultSet.getString("EM_NAME"));
				employee.setDateOfBirth(resultSet.getDate("EM_DATE_OF_BIRTH"));
				employee.setGender(resultSet.getString("EM_GENDER"));
				employee.setSalary(resultSet.getInt("EM_SALARY"));
				employee.setEmail(resultSet.getString("EM_EMAIL"));
				employee.setDepartmentId(resultSet.getInt("DP_ID"));
				employee.setDepartmentName(resultSet.getString("DP_NAME"));
				employee.setSkills(resultSet.getString("SKILLS"));
				Address address = new Address();
				address.setAddressLine1(resultSet.getString("AD_ADDRESS_LINE_1"));
				address.setAddressLine2(resultSet.getString("AD_ADDRESS_LINE_2"));
				address.setLocality(resultSet.getString("AD_LOCALITY"));
				address.setCity(resultSet.getString("AD_CITY"));
				address.setPinCode(resultSet.getInt("AD_PINCODE"));
				employee.setAddress(address);
			}
		} catch (SQLException exception) {
			exception.printStackTrace();
			throw new PayrollException("Error when getting all departments", exception);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException exception) {
				throw new PayrollException("Error when getting all departments", exception);
			}
		}
 		return employee;
	}

	public void updateEmployee(Connection connection, Employee employee, int departmentId) throws PayrollException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(UPDATE_EMPLOYEE_SQL);
			statement.setString(1, employee.getName());
			statement.setDate(2, new java.sql.Date(employee.getDateOfBirth().getTime()));
			statement.setString(3, employee.getGender());
			statement.setInt(4, (int) employee.getSalary());
			statement.setString(5, employee.getEmail());
			statement.setInt(6, departmentId);
			statement.setInt(7, employee.getId());
			statement.execute();
		} catch (SQLException exception) {
			exception.printStackTrace();
			throw new PayrollException("Error when updating employee", exception);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException exception) {
				throw new PayrollException("Error when updating employee", exception);
			}
		}
	}

	public void updateAddress(Connection connection, Address address) throws PayrollException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(UPDATE_ADDRESS_SQL);
			statement.setString(1, address.getAddressLine1());
			statement.setString(2, address.getAddressLine2());
			statement.setString(3, address.getLocality());
			statement.setString(4, address.getCity());
			statement.setInt(5, address.getPinCode());
			statement.setInt(6, address.getId());
			statement.execute();
		} catch (SQLException exception) {
			exception.printStackTrace();
			throw new PayrollException("Error when updating address", exception);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException exception) {
				throw new PayrollException("Error when updating address", exception);
			}
		}
	}

	public void addSkill(Connection connection, int employeeId, int skillId) throws PayrollException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement("insert into employee_skill (es_em_id, es_sk_id) values (?, ?)");
			statement.setInt(1, employeeId);
			statement.setInt(2, skillId);
			statement.execute();
		} catch (SQLException exception) {
			exception.printStackTrace();
			throw new PayrollException("Error when adding skill to employee", exception);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException exception) {
				throw new PayrollException("Error when adding skill to employee", exception);
			}
		}
	}

	public void deleteSkills(Connection connection, int employeeId) throws PayrollException {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement("delete from employee_skill where es_em_id = ?");
			statement.setInt(1, employeeId);
			statement.execute();
		} catch (SQLException exception) {
			exception.printStackTrace();
			throw new PayrollException("Error when deleting employee skills", exception);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException exception) {
				throw new PayrollException("Error when deleting employee skills", exception);
			}
		}
	}
}
