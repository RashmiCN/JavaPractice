package com.heb.atiumt2.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.heb.atiumt2.model.Employee;

@Component
public class EmployeeDao {
	
	private static final String GET_ALL_EMP_QUERY = 
		"	  select em_id, em_name, em_date_of_birth, em_gender, em_salary," + 
		"            em_email, dp_id, dp_name, ad_id, ad_address_line_1, ad_address_line_2, ad_locality," + 
		"            ad_city, ad_pincode, listagg(sk_name, ', ') within group (order by sk_name) skills" +
		"    from employee, department, address, skill, employee_skill " +
		"   where em_ad_id = ad_id " + 
		"     and em_dp_id = dp_id " + 
		"     and em_id = es_em_id " + 
		"     and sk_id = es_sk_id " + 
		"group by em_id, em_name, em_date_of_birth, em_gender, em_salary, " + 
		"         em_email, dp_id, dp_name, ad_id, ad_address_line_1, ad_address_line_2, ad_locality, " + 
		"         ad_city, ad_pincode";
	
	private static final String UPDATE_EMPLOYEE_SQL = "Update EMPLOYEE set em_name = ?, em_date_of_birth = ?, " +
		"em_gender = ?, em_salary = ?, em_email = ?, em_dp_id = ? where em_id = ?";

	private static final String GET_EMP_QUERY = 
			"	  select em_id, em_name, em_date_of_birth, em_gender, em_salary," + 
			"            em_email, dp_id, dp_name, ad_id, ad_address_line_1, ad_address_line_2, ad_locality," + 
			"            ad_city, ad_pincode, listagg(sk_name, ', ') within group (order by sk_name) skills" +
			"    from employee, department, address, skill, employee_skill " +
			"   where em_id = ? " + 
			"     and em_ad_id = ad_id " + 
			"     and em_dp_id = dp_id " + 
			"     and em_id = es_em_id " + 
			"     and sk_id = es_sk_id " + 
			"group by em_id, em_name, em_date_of_birth, em_gender, em_salary, " + 
			"         em_email, dp_id, dp_name, ad_id, ad_address_line_1, ad_address_line_2, ad_locality, " + 
			"         ad_city, ad_pincode";
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public EmployeeDao(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	/*@Autowired
	public void setDataSource(DataSource dataSource) {	
		System.out.println("inside setDataSource()");
		this.dataSource = dataSource;
	}*/
	
	public List<Employee> getAllEmployees() {
		return jdbcTemplate.query(GET_ALL_EMP_QUERY, new EmployeeMapper());
	}
	
	public Employee getEmployee(int id) {
		return jdbcTemplate.queryForObject(
				GET_EMP_QUERY, 
				new Object[] { id }, 
				new EmployeeMapper());
	}
	
	public boolean updateEmployee(Employee employee) {
		return jdbcTemplate.update(
				UPDATE_EMPLOYEE_SQL,
				employee.getName(),
				employee.getDateOfBirth(),
				employee.getGender(),
				employee.getSalary(),
				employee.getEmail(),
				employee.getDepartmentId(),
				employee.getId()
			) > 0;
	}
	
	public boolean deleteEmployeeSkills(int employeeId) {
		return jdbcTemplate.update(
				"delete from employee_skill where es_em_id = ?",
				employeeId
			) > 0;
	}

	public boolean addSkill(int employeeId, int skillId) {
		return jdbcTemplate.update(
				"insert into employee_skill (es_em_id, es_sk_id) values (?, ?)",
				employeeId,
				skillId
			) > 0;
	}

}
