package com.heb.atiumt2.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.heb.atiumt2.model.Department;

@Component
public class DepartmentDao {
	
	private static final String GET_ALL_DEPARTMENT = "select * from department";

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public DepartmentDao(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public List<Department> getAllDepartments() {
		return jdbcTemplate.query(GET_ALL_DEPARTMENT, new DepartmentMapper());
	}
	
}
