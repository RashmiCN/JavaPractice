package com.heb.atiumt2.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.heb.atiumt2.exception.PayrollException;

public class DatabaseConnection {
	
	public static Connection getConnection() throws PayrollException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			throw new PayrollException("Error when loading JDBC Driver", e);
		}
		Connection connection;
		try {
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", 
					"payroll", "password");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollException("Error when connecting to database", e);
		}
		return connection;

	}

}
