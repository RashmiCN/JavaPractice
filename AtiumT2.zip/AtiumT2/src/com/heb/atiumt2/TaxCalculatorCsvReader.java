package com.heb.atiumt2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;

import com.heb.atiumt2.model.Employee;

import java.util.ArrayList;

public class TaxCalculatorCsvReader implements TaxCalculatorFileReader {
    
    public List<Employee> readAll(String fileNameWithPath) {
        List<Employee> employees = new ArrayList<Employee>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileNameWithPath));
            String line = reader.readLine();
            while (line != null) {
                employees.add(new Employee(line));
                Employee employee = new Employee(line);
                line = reader.readLine();
            }
            reader.close();
            System.out.println("read all employees");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("inside exception");
        }
        return employees;
    }
}