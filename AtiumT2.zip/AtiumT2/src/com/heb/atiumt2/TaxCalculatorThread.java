package com.heb.atiumt2;

import com.heb.atiumt2.model.AbstractTaxCalculator;
import com.heb.atiumt2.model.Employee;

public class TaxCalculatorThread extends Thread {
    private AbstractTaxCalculator taxCalculator;
    private Employee employee;
    private static long counter = 0;
    
    public TaxCalculatorThread(AbstractTaxCalculator taxCalculator,
                Employee employee) {
        this.taxCalculator = taxCalculator;
        this.employee = employee;
    }
    
    public void run() {
        //System.out.print("run ");
        employee.setTaxAmount(taxCalculator.calculateTax());
        System.out.print(++counter + " ");
    }
}
