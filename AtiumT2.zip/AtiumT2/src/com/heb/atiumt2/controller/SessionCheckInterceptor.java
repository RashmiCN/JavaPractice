package com.heb.atiumt2.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class SessionCheckInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, 
			HttpServletResponse response, Object handler)
			throws Exception {
		System.out.println("Inside prehandle");
		if (!request.getRequestURI().endsWith("/app/home") && 
				request.getSession().getAttribute("user") != null) {
			response.sendRedirect("app/home");
		}
		return super.preHandle(request, response, handler);
	}
	
}
