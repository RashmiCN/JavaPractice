package com.heb.atiumt2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.heb.atiumt2.model.Address;
import com.heb.atiumt2.model.Employee;
import com.heb.atiumt2.service.DepartmentService;
import com.heb.atiumt2.service.EmployeeService;
import com.heb.atiumt2.service.SkillService;

@RestController
public class EmployeeRestController {

	private EmployeeService employeeService;
	private DepartmentService departmentService;
	private SkillService skillService;

	@Autowired
	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	@Autowired
	public void setDepartmentService(DepartmentService departmentService) {
		this.departmentService = departmentService;
	}

	@Autowired
	public void setSkillService(SkillService skillService) {
		this.skillService = skillService;
	}
	
	@GetMapping("/rest/employee/list")
	public List<Employee> getAllEmployees() {
		return employeeService.getAllEmployees();
	}
	
	@PostMapping("/rest/employee/update")
	@ResponseBody
	public JsonResponse update(Employee employee, Address address) {
		employee.setAddress(address);
		System.out.println("Rest update - " + employee);
		JsonResponse response = new JsonResponse("SUCCESS");
		employeeService.updateEmployee(employee);
		return response;
	}
}
