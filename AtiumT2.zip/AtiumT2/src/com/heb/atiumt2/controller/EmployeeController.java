package com.heb.atiumt2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.heb.atiumt2.model.Address;
import com.heb.atiumt2.model.Employee;
import com.heb.atiumt2.service.DepartmentService;
import com.heb.atiumt2.service.EmployeeService;
import com.heb.atiumt2.service.SkillService;

@Controller
public class EmployeeController {
	private EmployeeService employeeService;
	private DepartmentService departmentService;
	private SkillService skillService;

	@Autowired
	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	@Autowired
	public void setDepartmentService(DepartmentService departmentService) {
		this.departmentService = departmentService;
	}

	@Autowired
	public void setSkillService(SkillService skillService) {
		this.skillService = skillService;
	}
	
	@GetMapping("/employee/get/{id}")
	public String showEmployeeDetails(@PathVariable int id, Model model) {
		Employee employee = employeeService.getEmployee(id);
		System.out.println(employee);
		model.addAttribute("employee", employee);
		model.addAttribute("skills", skillService.getAllSkills());
		model.addAttribute("departments", departmentService.getAllDepartments());
		return "editemp";
	}
	
	@PostMapping("/employee/update")
	public String updateEmployee(Employee employee, Address address, Model model) {
		System.out.println(employee);
		employee.setAddress(address);
		employeeService.updateEmployee(employee);
		model.addAttribute("employee", employeeService.getEmployee(employee.getId()));
		model.addAttribute("skills", skillService.getAllSkills());
		model.addAttribute("departments", departmentService.getAllDepartments());
		return "editemp";
	}
	
	@GetMapping("/employee/list")
	public String showEmployeesList(Model model) {
		model.addAttribute("employees", employeeService.getAllEmployees());
		return "emplist";
	}
}
