package com.heb.atiumt2.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.heb.atiumt2.model.User;
import com.heb.atiumt2.service.EmployeeService;

@Controller
public class LoginController {
	
	private EmployeeService employeeService;
	
	@Autowired
	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}
	
	@GetMapping("/home")
	public String showLogin() {
		return "login";
	}
	
	@PostMapping("/authenticate")
	public String authenticate(User user, Model model, HttpServletRequest request) {
		request.getSession().setAttribute("user", user);
		model.addAttribute("employees", employeeService.getAllEmployees());
		return "emplist";
	}

}
