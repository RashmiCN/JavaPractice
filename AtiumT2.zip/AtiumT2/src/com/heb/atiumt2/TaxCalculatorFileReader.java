package com.heb.atiumt2;

import java.util.List;

import com.heb.atiumt2.model.Employee;

public interface TaxCalculatorFileReader {
	//public void openFile(String fileNameWithPath);
	public List<Employee> readAll(String fileNameWithPath);
	//public void closeFile();
}
