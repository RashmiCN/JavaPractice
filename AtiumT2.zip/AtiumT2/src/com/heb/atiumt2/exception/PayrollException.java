package com.heb.atiumt2.exception;

public class PayrollException extends Exception {
	
	public PayrollException(String message, Exception exception) {
		super(message, exception);
	}

}
