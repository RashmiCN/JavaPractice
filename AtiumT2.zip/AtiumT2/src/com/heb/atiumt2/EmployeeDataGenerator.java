package com.heb.atiumt2;

import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;

public class EmployeeDataGenerator {

    private static String[] names = {
        "Muhammed Mcknight",
        "Taylan Haines",
        "Maximilian Doyle",
        "Jimi Vo",
        "Elicia Meyers",
        "Erica Brett",
        "Fannie Meyer",
        "Kailan Carver",
        "Dario Gibson",
        "Mylie Seymour",
        "Huda Compton",
        "Leopold Markham",
        "Rudra Waters",
        "Pauline Ho",
        "Sade Pritchard",
        "Zishan Horn",
        "Rory Kumar",
        "Nia Morton",
        "Arandeep Hawes",
        "Thalia Beil",
        "Alaw Neale",
        "Manpreet Gillespie",
        "Taha Koch",
        "Landon Ortiz",
        "Angus Davies",
        "Veronika Simmons",
        "Klara Carter",
        "Luc Justice",
        "Mathew Obrien",
        "Frazer Stone",
        "Derren Schmidt",
        "Sioned Mcmanus",
        "Arielle Howell",
        "Rhodri Field",
        "Julian Crouch",
        "Kieren O'Doherty",
        "Musab Mcculloch",
        "Aleksander Read",
        "Dina Jefferson",
        "Tamzin Kinney",
        "Antoine Conner",
        "Piper Atherton",
        "Oisin Morin",
        "Tyra Fellows",
        "Branden Scott",
        "Clay Almond",
        "Damien Quintero",
        "Nancy Hampton",
        "Dean Butler",
        "Shelby Salas",
        "Ailish Mccallum",
        "Rhianna Best",
        "Aran Branch",
        "Milana Finley",
        "Princess Brook",
        "Neive Coates",
        "Ammar Palacios",
        "Athena Irving",
        "Raj Maldonado",
        "Matthew Milner",
        "Kaine Bateman",
        "Paddy Humphreys",
        "Ann-Marie Bowler",
        "Evan Cooley",
        "Kendra Brandt",
        "Prisha Prentice",
        "Jodie Alston",
        "Jamelia Wynn",
        "Zane Green",
        "Corinne Lancaster",
        "Kareena Galindo",
        "Julien Devlin",
        "Jesus Mcnally",
        "Macauly Conroy",
        "Izaan Herbert",
        "Tyreese Major",
        "Jedd Shelton",
        "Daanyaal Ramirez",
        "Misha Kim",
        "Malcolm Thomson",
        "Elyse George",
        "Albi Odonnell",
        "Imaad Connelly",
        "Mai Dale",
        "Georgina Paine",
        "Bear Le",
        "Shola Dunkley",
        "Keziah Gibbs",
        "Isha Foster",
        "Imogen Woodcock",
        "Angela Gilliam",
        "Marnie Wilkins",
        "Rachelle Stubbs",
        "Leanna Esquivel",
        "Arwa Southern",
        "Fynley Roach",
        "Aras Pruitt",
        "Kaila Cornish",
        "Kourtney Black",
        "Cian Tomlinson"
    };

    public static void main(String args[]) {
        File file = new File("D:/employee.csv");
        if (file.exists()) {
            file.delete();
        }
        DecimalFormat format = new DecimalFormat("########");
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter("D:/employee.csv");
            for (int i = 1; i <= Integer.parseInt(args[0]); i++) {
                StringBuffer buffer = new StringBuffer();
                buffer.append(i);
                buffer.append(",");
                buffer.append(names[(int)(Math.random() * 99) + 1]);
                buffer.append(",");
                buffer.append((int)(Math.random() * 85));
                buffer.append(",");
                buffer.append(format.format(Math.random() * 10000000));
                buffer.append(",");
                buffer.append(i + "@xyz.com,");
                buffer.append("1 Madley Street,Bridge County,Langdon Manor,Newville,110228");
                buffer.append("\n");
                //System.out.print(buffer); 
                fileWriter.append(buffer.toString());
            }
        } catch (IOException exception) {
            System.out.println("Error creating file!!!");
        } finally {
            try {
                fileWriter.flush();
                fileWriter.close();
            } catch (IOException e) {
                System.out.println("Error creating file!!!");
            }
        }
    }
}
