package com.heb.atiumt2.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.heb.atiumt2.dao.OldEmployeeDao;
import com.heb.atiumt2.exception.PayrollException;
import com.heb.atiumt2.model.Address;
import com.heb.atiumt2.model.Employee;
import com.heb.atiumt2.service.EmployeeService;

@WebServlet("/empupdate")
public class UpdateEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UpdateEmployeeServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if (request.getSession().getAttribute("userName") == null) {
			response.sendRedirect("login.jsp");
			return;
		}
		Employee employee = new Employee();
		employee.setId(Integer.parseInt(request.getParameter("id")));
		employee.setName(request.getParameter("name"));
		employee.setGender(request.getParameter("gender"));
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			employee.setDateOfBirth(sdf.parse(request.getParameter("dateOfBirth")));
		} catch (ParseException e) {
			e.printStackTrace();
			request.setAttribute("message", "Incorrect Date Format. Should in dd/mm/yyyy format");
		}
		employee.setSalary((int) Float.parseFloat(request.getParameter("salary")));
		employee.setEmail(request.getParameter("email"));
		employee.setDepartmentId(Integer.parseInt(request.getParameter("department")));
		
		Address address = new Address();
		address.setId(Integer.parseInt(request.getParameter("addressId")));
		address.setAddressLine1(request.getParameter("addressLine1"));
		address.setAddressLine2(request.getParameter("addressLine2"));
		address.setLocality(request.getParameter("locality"));
		address.setCity(request.getParameter("city"));
		address.setPinCode(Integer.parseInt(request.getParameter("pincode")));
		employee.setAddress(address);
		
		int[] skills = toIntArray(request.getParameterValues("skills"));
		
		EmployeeService service = new EmployeeService();
		try {
			service.updateEmployee(employee, employee.getDepartmentId(), skills);
			request.setAttribute("success", "Employee details updated successfully");
		} catch (PayrollException e) {
			e.printStackTrace();
			request.setAttribute("message", e.getMessage());
		}
		OldEmployeeDao dao = new OldEmployeeDao();
		try {
			request.setAttribute("departments", dao.getAllDepartments());
			request.setAttribute("skills", dao.getAllSkills());
			request.setAttribute("employee", dao.getEmployee(employee.getId()));
		} catch (PayrollException e) {
			e.printStackTrace();
			request.setAttribute("message", e.getMessage());
		}
		RequestDispatcher rd = request.getRequestDispatcher("editemp.jsp");
		rd.forward(request, response);
	}
	
	private int[] toIntArray(String[] strings) {
		int[] integers = new int[strings.length];
		for (int i = 0; i < strings.length; i++) {
			integers[i] = Integer.parseInt(strings[i]);
		}
		return integers;
	}

}
