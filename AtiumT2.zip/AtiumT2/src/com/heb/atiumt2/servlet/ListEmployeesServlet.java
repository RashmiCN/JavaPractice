package com.heb.atiumt2.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heb.atiumt2.dao.OldEmployeeDao;
import com.heb.atiumt2.exception.PayrollException;

@WebServlet("/employeelist")
public class ListEmployeesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private OldEmployeeDao employeeDao;
       
    public ListEmployeesServlet() {
        super();
    }
    
    public void setEmployeeDao(OldEmployeeDao employeeDao) {
    	this.employeeDao = employeeDao;
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getSession().getAttribute("userName") == null) {
			response.sendRedirect("login.jsp");
			return;
		}
		OldEmployeeDao dao = new OldEmployeeDao();
		try {
			request.setAttribute("employees", dao.getAllEmployees());
		} catch (PayrollException e) {
			request.setAttribute("message", e.getMessage());
		}
		RequestDispatcher rd = request.getRequestDispatcher("emplist.jsp");
		rd.forward(request, response);
		//response.sendRedirect("emplist.jsp");
	}

}
