package com.heb.atiumt2.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.heb.atiumt2.dao.OldEmployeeDao;
import com.heb.atiumt2.exception.PayrollException;

@WebServlet("/authenticate")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public LoginServlet() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("userName");
		String password = request.getParameter("password");
		String forwardUrl;
		if (name.equals("admin") && password.equals("password")) {
			HttpSession session = request.getSession();
			session.setAttribute("userName", name);
			forwardUrl = "emplist.jsp";
			OldEmployeeDao dao = new OldEmployeeDao();
			try {
				request.setAttribute("employees", dao.getAllEmployees());
			} catch (PayrollException e) {
				request.setAttribute("message", e.getMessage());
			}
		} else {
			request.setAttribute("message", "Invalid Username or Password.");
			forwardUrl = "login.jsp";
		}
		RequestDispatcher rd = request.getRequestDispatcher(forwardUrl);
		rd.forward(request, response);
	}
}
