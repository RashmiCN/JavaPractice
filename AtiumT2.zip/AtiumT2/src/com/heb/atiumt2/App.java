package com.heb.atiumt2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.heb.atiumt2.dao.OldEmployeeDao;
import com.heb.atiumt2.exception.PayrollException;
import com.heb.atiumt2.model.Employee;

public class App {
	
	public static void main(String args[]) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Employee employee = (Employee) context.getBean("employee");
		Employee employee1 = (Employee) context.getBean("employee");
		Employee employee2 = (Employee) context.getBean("employee");
		Employee employee3 = (Employee) context.getBean("employee");
		System.out.println(employee);
		employee.setName("Paul");
		System.out.println(employee1);
		System.out.println(employee2);
		System.out.println(employee3);
		
		OldEmployeeDao dao = (OldEmployeeDao) context.getBean("employeeDao");
		try {
			dao.getAllEmployees();
			System.out.println("get all executed successfully");
		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
