package com.heb.atiumt2.model;

public class Above80TaxCalculator extends AbstractTaxCalculator {
	private static TaxSlab[] ABOVE_80_TAX_SLABS = {
		new TaxSlab(0.0, 500000.0, 0),
		new TaxSlab(500001.0, 1000000.0, 20),
		new TaxSlab(1000001.0, Double.MAX_VALUE, 30)
	};
	
	public Above80TaxCalculator(double annualIncome) {
		super(annualIncome);
		this.taxSlabs = ABOVE_80_TAX_SLABS;
	}
}