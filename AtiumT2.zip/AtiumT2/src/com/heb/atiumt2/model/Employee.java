package com.heb.atiumt2.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Employee {
	private int id;
	private String name;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date dateOfBirth;
	private int age;
	private String gender;
	private float salary;
	private int departmentId;
	private String departmentName;
    private String email;
	private Address address;
	private String skills;
    private double taxAmount;
    private int[] skillIds;
    
    public Employee() {
    	System.out.println("inside Employee constructors.");
    }
	
	public Employee(int id, String name, int age, float salary) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.salary = salary;
	}
    
    public Employee(String employeeData) {
        String[] data = employeeData.split(",");
        this.id = Integer.parseInt(data[0]);
        this.name = data[1];
        this.age = Integer.parseInt(data[2]);
        this.salary = Float.parseFloat(data[3]);
        this.email = data[4];
        this.address = new Address(data);
    }
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
	
	public float getSalary() {
		return salary;
	}
    
    public String getEmail() {
        return email;
    }
	
	public Address getAddress() {
		return address;
	}
    
    public double getTaxAmount() {
        return taxAmount;
    }
	
	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public void setAddress(Address address) {
        this.address = address;
    }

    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public boolean equals(Object object) {
		super.equals(object);
		if (object instanceof Employee) {
			Employee employee = (Employee) object;
			return (employee.getId() == this.id && 
				employee.getName().equals(this.name));
		}
		return false;
	}
	
	public int[] getSkillIds() {
		return skillIds;
	}

	public void setSkillIds(int[] skillIds) {
		this.skillIds = skillIds;
	}

	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Employee [id=");
		builder.append(id);
		builder.append(", name=");
		builder.append(name);
		builder.append(", dateOfBirth=");
		builder.append(dateOfBirth);
		builder.append(", age=");
		builder.append(age);
		builder.append(", gender=");
		builder.append(gender);
		builder.append(", salary=");
		builder.append(salary);
		builder.append(", departmentId=");
		builder.append(departmentId);
		builder.append(", departmentName=");
		builder.append(departmentName);
		builder.append(", email=");
		builder.append(email);
		builder.append(", address=");
		builder.append(address);
		builder.append(", skills=");
		builder.append(skills);
		builder.append(", taxAmount=");
		builder.append(taxAmount);
		builder.append(", skillIds=");
		builder.append(Arrays.toString(skillIds));
		builder.append("]");
		return builder.toString();
	}

	public static void main(String args[]) {
		Employee e1 = new Employee(1, "John", 25, 250000);
		Employee e2 = new Employee(2, "Smith", 25, 250000);
		Employee e3 = new Employee(1, "Paul", 55, 550000);
		
		List<Employee> employees = new ArrayList<Employee>();
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		
		for (Employee employee : employees) {
			System.out.println(employee);
		}
        
	}
}
