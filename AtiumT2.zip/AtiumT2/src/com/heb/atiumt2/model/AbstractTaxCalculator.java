package com.heb.atiumt2.model;

public abstract class AbstractTaxCalculator {
	protected double annualIncome;
	protected TaxSlab[] taxSlabs;
	
	public AbstractTaxCalculator(double annualIncome) {
		this.annualIncome = annualIncome;
	}
	
	public double calculateTax() {
		double totalTax = 0.0;
		for (TaxSlab taxSlab : taxSlabs) {
			totalTax += taxSlab.calculateSlabTax(annualIncome);
		}
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println("interrupted exception");
        }
        
		return totalTax;
	}
}
