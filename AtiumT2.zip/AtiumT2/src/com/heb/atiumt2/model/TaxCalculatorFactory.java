package com.heb.atiumt2.model;

public class TaxCalculatorFactory {

    public static AbstractTaxCalculator getTaxCalculator(Employee employee) {
        int age = employee.getAge();
        double salary = employee.getSalary();
        AbstractTaxCalculator calculator = null;
        if (age < 60) {
            calculator = new Under60TaxCalculator(salary);
        } else if (age >= 60 && age < 80) {
            calculator = new From60To80TaxCalculator(salary);
        } else if (age >= 80) {
            calculator = new Above80TaxCalculator(salary);
        }
        return calculator;
    }
}
