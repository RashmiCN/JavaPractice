package com.heb.atiumt2;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.CountDownLatch;

import com.heb.atiumt2.model.AbstractTaxCalculator;
import com.heb.atiumt2.model.Employee;
import com.heb.atiumt2.model.TaxCalculatorFactory;

public class TaxProcessor {
    
    public static void main(String args[]) throws InterruptedException {
        TaxProcessor processor = new TaxProcessor();
        processor.processTax();
    }
    
    public void processTax() throws InterruptedException {
        long startTime = System.nanoTime();
        TaxCalculatorFileReader reader = new TaxCalculatorCsvReader();
        List<Employee> employees = reader.readAll("d:/employee.csv");
        ExecutorService executor = Executors.newFixedThreadPool(100);
        //List<TaxCalculatorThread> threads = new ArrayList<TaxCalculatorThread>();
        for (Employee employee : employees) {
            AbstractTaxCalculator calculator = 
                TaxCalculatorFactory.getTaxCalculator(employee);
            TaxCalculatorThread thread = 
                    new TaxCalculatorThread(calculator, employee);
            //threads.add(thread);
            executor.execute(thread);
            //thread.start();
        }
        /*for (TaxCalculatorThread thread : threads) {
            thread.join();
        }*/
        //threads.forEach(thread -> try thread.join());
        executor.shutdown();
        while (!executor.isTerminated()) {
        }
        
        //employees.forEach(employee -> System.out.println(employee));
        employees.stream().filter(e -> e.getAge() > 60)
            .forEach(e -> System.out.println(e));
        
        //employees.forEach(employee -> System.out.println(employee));
        //System.out.println(employees.get(0));
        long duration = System.nanoTime() - startTime;
        System.out.println(duration/1000000000);
    }
}
