package com.heb.atiumt2.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.heb.atiumt2.dao.AddressDao;
import com.heb.atiumt2.dao.DatabaseConnection;
import com.heb.atiumt2.dao.EmployeeDao;
import com.heb.atiumt2.exception.PayrollException;
import com.heb.atiumt2.model.Employee;

@Service
public class EmployeeService {
	
	private EmployeeDao employeeDao;
	private AddressDao addressDao;
	
	@Autowired
	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}

	@Autowired
	public void setAddressDao(AddressDao addressDao) {
		this.addressDao = addressDao;
	}

	@Transactional
	public List<Employee> getAllEmployees() {
		return employeeDao.getAllEmployees();
	}
	
	@Transactional
	public Employee getEmployee(int employeeId) {
		return employeeDao.getEmployee(employeeId);
	}
	
	@Transactional
	public void updateEmployee(Employee employee) {
		employeeDao.updateEmployee(employee);
		addressDao.updateAddress(employee.getAddress());
		employeeDao.deleteEmployeeSkills(employee.getId());
		for (int skillId : employee.getSkillIds()) {
			employeeDao.addSkill(employee.getId(), skillId);
		}
	}
	
	public void updateEmployee(Employee employee, int departmentId, int[] skills) throws PayrollException {
		Connection connection = null;
		try {
			connection = DatabaseConnection.getConnection();
			connection.setAutoCommit(false);
			com.heb.atiumt2.dao.OldEmployeeDao dao = new com.heb.atiumt2.dao.OldEmployeeDao();
			dao.deleteSkills(connection, employee.getId());
			dao.updateEmployee(connection, employee, departmentId);
			dao.updateAddress(connection, employee.getAddress());
			for (int skillId: skills) {
				dao.addSkill(connection, employee.getId(), skillId);
			}
			connection.commit();
		} catch (PayrollException e) {
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
				throw new PayrollException("Error when rolling back employee update.", sqle);
			}
			throw e;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollException("Error when setting auto commit to false.", e);
		}
	}
}
