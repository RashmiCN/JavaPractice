package com.heb.atiumt2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.heb.atiumt2.dao.SkillDao;
import com.heb.atiumt2.model.Skill;

@Service
public class SkillService {
	
	private SkillDao skillDao;
	
	@Autowired
	public void setSkillDao(SkillDao skillDao) {
		this.skillDao = skillDao;
	}
	
	@Transactional
	public List<Skill> getAllSkills() {
		return skillDao.getAllSkills();
	}

}
