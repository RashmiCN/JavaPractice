function toRow(employee) {
    var html = "";
    html += "<tr>";
    html += "    <td>" + employee.id + "</td>";
    html += "    <td>" + employee.name + "</td>";
    html += "    <td>" + employee.dateOfBirth + "</td>";
    html += "    <td>" + employee.gender + "</td>";
    html += "    <td>" + employee.salary + "</td>";
    html += "    <td>" + employee.email + "</td>";
    html += "    <td>" + employee.departmentName + "</td>";
    html += "    <td>" + employee.skills + "</td>";
    /*var skills = employee.skills;
    for (var i = 0; i < skills.length; i++) {
        if (i == (skills.length - 1)) {
            html += skills[i];
        } else {
            html += skills[i] + ", ";
        }
    }
    html += "    </td>";*/
    html += "    <td>" + employee.address.addressLine1 + 
                  ", " + employee.address.addressLine2 + 
                  ", " + employee.address.locality + 
                  ", " + employee.address.city + 
                  " - " +  employee.address.pinCode + "</td>";
    html += "    <td><a href=''>Edit</a> <a href=''>Delete</a></td>";
    html += "</tr>";

    return html;
}

function tableHeader() {
    var html = "";
    html += "<table id='employees'>";
    html += "    <tr class='table-heading'>";
    html += "        <th>Id</td>";
    html += "        <th>Name</td>";
    html += "        <th>Date of Birth</td>";
    html += "        <th>Gender</td>";
    html += "        <th>Salary</td>";
    html += "        <th>Email</td>";
    html += "        <th>Department</td>";
    html += "        <th>Skills</td>";
    html += "        <th>Address</td>";
    html += "        <th>Modify / Delete</td>";
    html += "    </tr>";
    return html;
}

$(document).ready(function(){
	
	var prefix = "/payrollm"

    $.get(prefix + "/app/rest/employee/list", function(data, status) {
        var tableData = tableHeader();
        for (var i = 0; i < data.length; i++) {
            tableData += toRow(data[i]);
        }
        tableData += "</table>";
        $("#jsonEmpList").append(tableData);
    });

    $("#saveRestBtn").click(function() {
       if ($("#name").val() == "") {
           $("#err-name").text("Name cannot be empty");
           return;
       } else {
           $("#err-name").text("");
       }
       
       $.ajax({
    	   type: "POST",
           url : prefix + "/app/rest/employee/update",
           data : $('form[name=employeeForm]').serialize(),
           success : function(res) {
        	   $(".success").text("Employee details saved successfully.");
           },
           error: function(xhr, status, error) {
        	   alert("Save failed.");
           }
        })
    });
});
