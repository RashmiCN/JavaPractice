var app = angular.module('GetPost', [])
    app.controller('posts', function ($scope, $http) {
        $http.get('https://jsonplaceholder.typicode.com/posts').
            then(function (response) {
                $scope.posts = response.data;
            });
    });
    app.controller("postThePosts",function ($scope, $http){
        $scope.userId = null;
        $scope.id = null;
        $scope.title = null;
        $scope.body = null;
        $scope.postDataJson = function(userID,id,title,body){
        var data = {
            userId:userID,
            // id:id,
            title:title,
            body:body
        };
        var putdata = {
            userId:userID,
            id:id,
            title:title,
            body:body
        };
        console.log(data);
        console.log(JSON.stringify(data));
        console.log(putdata);
        console.log(JSON.stringify(putdata));
        $http.post('https://jsonplaceholder.typicode.com/posts',JSON.stringify(data));
        $http.put('https://jsonplaceholder.typicode.com/posts', JSON.stringify(putdata));
    }
    $scope.putDataJson = function (userID, id, title, body){
        var putdata = {
            userId:userID,
            id:id,
            title:title,
            body:body
        };
        console.log(putdata);
        console.log(JSON.stringify(putdata));
            console.log('https://jsonplaceholder.typicode.com/posts/'+id)
            $http.put('https://jsonplaceholder.typicode.com/posts/'+id, JSON.stringify(putdata));
    }
    $scope.delDataJson = function (userID, id, title, body){
        var deldata = {
            userId:userID,
            id:id,
            title:title,
            body:body
        };
        console.log(deldata);
        console.log(JSON.stringify(deldata));
            console.log('https://jsonplaceholder.typicode.com/posts/'+id)
            $http.delete('https://jsonplaceholder.typicode.com/posts/'+id);
    }
    });