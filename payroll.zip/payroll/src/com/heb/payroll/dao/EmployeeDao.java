package com.heb.payroll.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.heb.payroll.servlet.PayrollException;
import com.heb.taxcalculator.model.Address;
import com.heb.taxcalculator.model.Department;
import com.heb.taxcalculator.model.Employee;
import com.heb.taxcalculator.model.Skill;

public class EmployeeDao {
	
	private static final String GET_ALL_EMP_QUERY = 
			"	  select em_id, em_name, em_date_of_birth, em_gender, em_salary," + 
			"            em_email, dp_name, ad_address_line_1, ad_address_line_2, ad_locality," + 
			"            ad_city, ad_pincode, listagg(sk_name, ', ') within group (order by sk_name) skills" +
			"    from employee, department, address, skill, employee_skill " +
			"   where em_ad_id = ad_id " + 
			"     and em_dp_id = dp_id " + 
			"     and em_id = es_em_id " + 
			"     and sk_id = es_sk_id " + 
			"group by em_id, em_name, em_date_of_birth, em_gender, em_salary, " + 
			"         em_email, dp_name, ad_address_line_1, ad_address_line_2, ad_locality, " + 
			"         ad_city, ad_pincode";
	
	private static final String GET_ONE_EMP_QUERY = 
			"	  select em_id, em_name, em_date_of_birth, em_gender, em_salary," + 
			"            em_email, dp_name, ad_address_line_1, ad_address_line_2, ad_locality," + 
			"            ad_city, ad_pincode, listagg(sk_name, ', ') within group (order by sk_name) skills" +
			"    from employee, department, address, skill, employee_skill " +
			"   where em_ad_id = ad_id " + 
			"     and em_ad_id = ?"       +
			"     and em_dp_id = dp_id " + 
			"     and em_id = es_em_id " + 
			"     and sk_id = es_sk_id " + 
			"group by em_id, em_name, em_date_of_birth, em_gender, em_salary, " + 
			"         em_email, dp_name, ad_address_line_1, ad_address_line_2, ad_locality, " + 
			"         ad_city, ad_pincode";
	
	
	private static final String GET_ALL_DEPT_QUERY = 
			"	  select DP_ID,DP_NAME " +
			"    from department ";
	
	private static final String UPDATE_EMP_QUERY = 
			"update EMPLOYEE " +
			" SET EM_NAME = ?, " +
			" em_date_of_birth = ?," +		
			" EM_GENDER = ?, " +
			" EM_SALARY = ?, " +
			" EM_EMAIL= ?, " +
			" EM_DP_ID = ?" +
			" WHERE EM_ID = ?";
			;
	
	public List<Employee> getAllEmployees() throws PayrollException {
		
		Connection connection = ConnectionManager.getConnection();
		Statement statement = null;
		ResultSet resultSet = null;
		List<Employee> employees = new ArrayList<Employee>();
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(GET_ALL_EMP_QUERY);
			while(resultSet.next()) {
				
				Employee employee = new Employee();
				employee.setId(resultSet.getInt("EM_ID"));
				employee.setName(resultSet.getString("EM_NAME"));
				employee.setDateofBirth(resultSet.getDate("EM_DATE_OF_BIRTH"));
				employee.setGender(resultSet.getString("EM_GENDER"));
				employee.setSalary(resultSet.getDouble("EM_SALARY"));
				employee.setEmail(resultSet.getString("EM_EMAIL"));
				employee.setSkills(resultSet.getString("SKILLS"));
				employee.setDepartmentName(resultSet.getString("DP_NAME"));
				
				Address address = new Address();
				
				address.setAddressLine1(resultSet.getString("ad_address_line_1"));
				address.setAddressLine2(resultSet.getString("ad_address_line_2"));
				address.setLocality(resultSet.getString("ad_locality"));
				address.setCity(resultSet.getString("ad_city"));
				address.setPincode(resultSet.getString("ad_pincode"));
				
				employee.setAddress(address);
				employees.add(employee);
			
			}
		}catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("Error when getting all employees",e);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if(statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch(SQLException e) {
				e.printStackTrace();
				throw new PayrollException("error while closing the connections" ,e);
			}
		}
		return employees;
	}//end of getAllEmployees methods

	
	public List<Department> getAllDepartment() throws PayrollException {		
		Connection connection = ConnectionManager.getConnection();
		Statement statement = null;
		ResultSet resultSet = null;
		List<Department> departments = new ArrayList<Department>();
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(GET_ALL_DEPT_QUERY);
			while(resultSet.next()) {
				
				Department department = new Department();
				department.setId(resultSet.getInt("DP_ID"));
				department.setName(resultSet.getString("DP_NAME"));
				departments.add(department);
				
			
			}
		}catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("Error when getting all employees",e);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if(statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch(SQLException e) {
				e.printStackTrace();
				throw new PayrollException("error while closing the connections" ,e);
			}
		}
		return departments;
	}//end of getAlldepartments methods
	
	public List<Skill> getAllSkill() throws PayrollException {
		
		Connection connection = ConnectionManager.getConnection();
		Statement statement = null;
		ResultSet resultSet = null;
		List<Skill>  skills = new ArrayList<Skill>();
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery("select * from skill");
			while(resultSet.next()) {
				
				Skill skill = new Skill();
				 skill.setId(resultSet.getInt("SK_ID"));
				 skill.setName(resultSet.getString("SK_NAME"));
				 skills.add(skill);
			
			}
		}catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("Error when getting all skills",e);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if(statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch(SQLException e) {
				e.printStackTrace();
				throw new PayrollException("error while closing the connections" ,e);
			}
		}
		return skills;
	}//end of getAlldepartments method
	
	
public Employee getOneEmployees(int employeeId) throws PayrollException {
		
		Connection connection = ConnectionManager.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Employee employee = new Employee();
		System.out.println("before try: " + employeeId);
		try {
			
			statement = connection.prepareStatement(GET_ONE_EMP_QUERY);
			statement.setInt(1,employeeId);
			resultSet = statement.executeQuery();
			System.out.println("before if: " + employeeId);
			boolean val = resultSet.next();
			System.out.println(val);
			if(val) {
				System.out.println("inside if: " + employeeId);
				employee.setId(resultSet.getInt("EM_ID"));
				System.out.println("id:" + resultSet.getInt("EM_ID"));
				employee.setName(resultSet.getString("EM_NAME"));
				employee.setDateofBirth(resultSet.getDate("EM_DATE_OF_BIRTH"));
				employee.setGender(resultSet.getString("EM_GENDER"));
				employee.setSalary(resultSet.getDouble("EM_SALARY"));
				employee.setEmail(resultSet.getString("EM_EMAIL"));
				employee.setSkills(resultSet.getString("SKILLS"));
				employee.setDepartmentName(resultSet.getString("DP_NAME"));
				
				Address address = new Address();
				
				address.setAddressLine1(resultSet.getString("ad_address_line_1"));
				address.setAddressLine2(resultSet.getString("ad_address_line_2"));
				address.setLocality(resultSet.getString("ad_locality"));
				address.setCity(resultSet.getString("ad_city"));
				address.setPincode(resultSet.getString("ad_pincode"));
				
				employee.setAddress(address);
			
		}
		}catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("Error when getting all employees",e);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if(statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch(SQLException e) {
				e.printStackTrace();
				throw new PayrollException("error while closing the connections" ,e);
			}
		}
		return employee;
	}//end of getAllEmployees methods


public void updateEmployee(Employee employee,int departmentId) throws PayrollException {
	
	Connection connection = ConnectionManager.getConnection();
	PreparedStatement statement = null;

	

	try {
		statement = connection.prepareStatement(UPDATE_EMP_QUERY);
		statement.setString(1,employee.getName());
		statement.setDate(2,new  java.);
		statement.setString(2,employee.getGender());
		statement.setDouble(3, employee.getSalary());
		statement.setString(4,employee.getEmail());
		statement.setInt(5, departmentId);
		statement.setInt(6,employee.getId());
			
		int i = statement.executeUpdate();
		System.out.println("I VALUE: " + i);
		}catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("Error when getting all employees",e);
		} finally {
			try {
				if(statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("error while closing the connections" ,e);
			}
		}	
}//end of updateEmployee


}//end of class
















