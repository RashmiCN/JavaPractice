package com.heb.payroll.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.heb.payroll.servlet.PayrollException;

public class ConnectionManager {
	public static Connection getConnection() throws PayrollException{
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch(ClassNotFoundException e) {
				e.printStackTrace();
				throw new PayrollException("error when loading JDBC driver" ,e);
			}
		Connection connection = null;
		try {
			connection = DriverManager.getConnection("jdbc:oracle:thin:@pc233323:1521:xe", "payroll", "password");
		} catch(SQLException e) {
			e.printStackTrace();
			throw new PayrollException("Error when connecting to DB",e);
		}
		return connection ;
		
	}//end of connection method
}//end of class
