package com.heb.payroll.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heb.payroll.dao.EmployeeDao;
import com.heb.taxcalculator.model.Employee;

/**
 * Servlet implementation class EmployeeUpdateServlet
 */
@WebServlet("/empedit")
public class EmployeeUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EmployeeUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Employee employee = new Employee();
		employee.setName(request.getParameter("empName"));
		Date dob = null;
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		try{
			dob = formatter.parse(request.getParameter("empDateOfBirth"));
		}catch(ParseException e){
			e.printStackTrace();
			
		}
		employee.setGender(request.getParameter("empGender"));
		employee.setDateofBirth(dob);
		employee.setSalary(Double.parseDouble(request.getParameter("empSalary")));
		employee.setEmail(request.getParameter("empEmail"));
		
		EmployeeDao empDao = new EmployeeDao();
		try{
			empDao.updateEmployee( employee, Integer.parseInt(request.getParameter("empDepartment")));
		}catch(PayrollException e){
			request.setAttribute("error", e.getMessage());
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("editemp.jsp");
		dispatcher.forward(request, response);
	
	}//end of doPost method

}//end of class
