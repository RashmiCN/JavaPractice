package com.heb.payroll.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/listemployees")
public class GetEmployeeListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

  
    public GetEmployeeListServlet() {
    	System.out.println("inside get");
    }

	public void init(ServletConfig config) throws ServletException {
		System.out.println("inside init");
	}

	public void destroy() {
		System.out.println("inside destroy");

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("inside DoGet");
		System.out.println(request.getParameter("age"));
		System.out.println(request.getParameter("name"));
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//PrintWriter out = response.getWriter();
		//out.println("<!DOCTYPE html>");
		//out.println("<html>");
		//out.println("<head>");
		//out.println("</head>");
		//out.println("<body>");
		//out.println("<h1>Hello world</h1>");
		//out.println("</body>");
		//out.println("</html>");
		
		RequestDispatcher rd = request.getRequestDispatcher("employee.html");
		rd.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("inside doPost");
		doGet(request, response);
	}

}
