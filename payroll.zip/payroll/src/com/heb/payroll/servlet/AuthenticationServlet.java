package com.heb.payroll.servlet;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heb.payroll.dao.EmployeeDao;



@WebServlet("/authenticate")
public class AuthenticationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AuthenticationServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	//protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	//}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		
		String responseUrl = "";
		
		if(userName.equals("admin") && password.equals("password")) {
		
			responseUrl ="employee.jsp";
			EmployeeDao dao = new EmployeeDao();
			try{
				request.setAttribute("employees",dao.getAllEmployees());
			} catch(PayrollException e) {
				request.setAttribute("message",e.getMessage());
				
			}
			
			
		} else {
			request.setAttribute("message","Invalid UserName or Password");
		    responseUrl ="login.jsp";
			
		}
			
		System.out.println(userName);
		System.out.println(password);
		RequestDispatcher rd = request.getRequestDispatcher(responseUrl);
		rd.forward(request, response);
	
	}

}
