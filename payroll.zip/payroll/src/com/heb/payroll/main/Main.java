package com.heb.payroll.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.heb.taxcalculator.model.Address;
import com.heb.taxcalculator.model.Employee;

public class Main {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		Address address = (Address) context.getBean("address");
		System.out.println(address);
		Employee employee = (Employee) context.getBean("employee");
		Employee employee2 = (Employee) context.getBean("employee");
		System.out.println( employee);
		System.out.println( employee2);
		Employee employee3 = (Employee) context.getBean("employee");
		Employee employee4 = (Employee) context.getBean("employee");
		System.out.println( employee3);
		System.out.println( employee4);
		
		
	}//end of main method
}//end of class
