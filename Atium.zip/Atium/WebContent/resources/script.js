$(document).ready(function(){
	console.log("executing the script");
	 $(".btn").click(function() {
		 
		 if($(this).closest("tr").find('#qty').val() == 0)
			 {
			 alert("Please key in Quantity to be Ordered");
			 return;
			 }
		 var data = {}
		 data["productID"] = $(this).closest("tr").find('.prodID').val();
		 console.log("prodid :"+data["productID"]);
		 data["productName"] = $(this).closest("tr").find('.prodName').val();
		 console.log("prodName :"+data["productName"]);
		 data["manufacturer"] = $(this).closest("tr").find('.manf').val();
		 console.log("manf :"+data["manufacturer"]);
		 data["price"] = $(this).closest("tr").find('.prc').val();
		 console.log("price :"+data["price"]);
		 data["rating"]  =  $(this).closest("tr").find('.rate').val();
		 console.log("rating :"+data["rating"]);
		 data["onHandQty"]  = $(this).closest("tr").find('#qty').val();
		 console.log("ordered :"+data["onHandQty"]);
		 console.log("ajax call to controller");
		  $.ajax({
	         type: "POST",
	           url :"product/update",
	           data : JSON.stringify(data),
	           contentType: "application/json",
	           Accept: "application/json",
	           success : function(response) {
	        	   console.log(response.status);
	        	    if(response.status==0)
	        		   {
	        	   			alert("Thanks for Shopping at Atium Reference Order# : " + response.orderid);
	        		   }
	        	   else
	        		   {
	        		   alert("Thanks for Shopping at Atium Reference Order# : " + response.orderid);
	        		   		alert("Oops Something went wrong! Please try again after few minutes.");
	        		   }
	        	    document.getElementById("productform").reset();
	           },
	           error: function(response) {
		        	   console.log(response.status);
		       	    if(response.status==0)
		       		   {
		       	   			alert("Thanks for Shopping at Atium Reference Order# : " + response.orderid);
		       		   }
		       	   else
		       		   {
		       		   		alert("Thanks for Shopping at Atium Reference Order# : " + response.orderid);
		       		   		alert("Oops Something went wrong! Please try again after few minutes.");
		       		   }
		       	    document.getElementById("productform").reset();
		          }
	        })

	    });

	});
