package com.heb.atium.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.heb.atium.model.Orders;
import com.heb.atium.model.ProductDetails;
import com.heb.atium.service.ProductService;

@Component
public class OrdersDAO {
	private ProductMasterDAO pmdao;

	private JdbcTemplate jdbcTemplate;

	private static final String INSERT_ORDER =
			"insert into orders (order_id,prod_id,prod_name,manf_name,price,order_qty ,total_price,orderDate,"
			+ "deliveryDate,comments) values (ord_sequence.nextval,?,?,?,?,?,?,?,?,?)";
	
	private static final String GET_ORDER_ID =
			"select max(order_id) from orders ";
	
	public OrdersDAO() {
		super();
	}
	
	@Autowired
	public void setProductMasterDAO(ProductMasterDAO pmdao) {
		this.pmdao = pmdao;
	}
	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	@Autowired
	public OrdersDAO(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}


	public void insertOrder(int qty, int productID) { 
		System.out.println("inserting the order.................");
//		ProductDetails pdtl = new ProductDetails();
		Orders order =new Orders();
		ProductDetails pdtl = pmdao.getProduct(productID);
		System.out.println(pdtl);
		float totalPrice = pdtl.getPrice() * qty;
		System.out.println("inserting the order1.................");
		String comnt = "Order placed for " + pdtl.getProductName() + "to be delivered by :" + order.getDeliveryDateIns();
		System.out.println(comnt);
		Object[] fields = {
				pdtl.getProductID(),pdtl.getProductName(),pdtl.getManufacturer(),
				pdtl.getPrice(),qty,totalPrice,order.getOrderDateIns(),order.getDeliveryDateIns(),comnt
		};
		jdbcTemplate.update(INSERT_ORDER, fields);
	}
	
	
	public int getOrderId(){
		
		int orderid = (int) jdbcTemplate.queryForObject(GET_ORDER_ID,new Object [] {} ,Integer.class);
		return orderid;

	};

}
