package com.heb.atium.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.heb.atium.model.ProductDetails;

public class ProductMapper implements RowMapper<ProductDetails>{
	@Override   
	public ProductDetails mapRow(ResultSet resultSet, int i) throws SQLException {
		System.out.println("in row mapper");
		ProductDetails prodDetail = new ProductDetails();
		prodDetail.setProductID(resultSet.getInt("prod_id"));
		prodDetail.setProductName(resultSet.getString("prod_name"));
		prodDetail.setManufacturer(resultSet.getString("manf_name"));
		prodDetail.setPrice(resultSet.getFloat("price"));
		prodDetail.setRating(resultSet.getFloat("rating"));
		prodDetail.setOnHandQty(resultSet.getInt("on_hand_qty"));
		prodDetail.setOnOrderQty(resultSet.getInt("on_order_qty"));
		System.out.println(prodDetail);
		return prodDetail;
	}
}
