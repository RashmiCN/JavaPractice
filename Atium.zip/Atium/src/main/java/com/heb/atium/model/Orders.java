package com.heb.atium.model;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Orders {
	
	private int orderID;
	private String productID;
	private String productName;
	private String manufacturer;
	private float price;
	private int orderQty; 
	private float totalPrice;
	private String orderDate;
	private String deliveryDate;
	private String comments;
	public int getOrderID() {
		return orderID;
	}
	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	public String getProductID() {
		return productID;
	}
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getOrderQty() {
		return orderQty;
	}
	public void setOrderQty(int orderQty) {
		this.orderQty = orderQty;
	}
	public float getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getOrderDateIns() {
		SimpleDateFormat cdf = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		System.out.println(cdf.format(date));
		return cdf.format(date);
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getDeliveryDateIns() {
		SimpleDateFormat fdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, 3);
		System.out.println(fdf.format(c.getTime()));
		return fdf.format(c.getTime());
	}
	public String getOrderDate() {
		return orderDate;
	}
	public String getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "Orders [orderID=" + orderID + ", productID=" + productID + ", productName=" + productName
				+ ", manufacturer=" + manufacturer + ", price=" + price + ", orderQty=" + orderQty + ", totalPrice="
				+ totalPrice + ", orderDate=" + orderDate + ", deliveryDate=" + deliveryDate + ", comments=" + comments
				+ "]";
	}
	public Orders() {
		super();
	}
	
	
	
}
