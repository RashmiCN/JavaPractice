package com.heb.atium.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.heb.atium.model.*;
import com.heb.atium.dao.ProductMasterDAO;

@Service
public class ProductService {
	private ProductMasterDAO pmdao;

	@Autowired
	public void setProdDAO(ProductMasterDAO pmdao) {
		this.pmdao = pmdao;
	}
	

	@Transactional
	public List<ProductDetails> getAllProds() {
		System.out.println("in service");
		return pmdao.getAllProducts();
	}
	

}
