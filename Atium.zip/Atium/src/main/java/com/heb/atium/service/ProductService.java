package com.heb.atium.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.heb.atium.model.*;
import com.heb.atium.controller.JsonResponse;
import com.heb.atium.dao.OrdersDAO;
import com.heb.atium.dao.ProductMasterDAO;

@Service
public class ProductService {
	private ProductMasterDAO pmdao;
	private OrdersDAO odao;
	
	@Autowired
	public void setProdDAO(ProductMasterDAO pmdao) {
		this.pmdao = pmdao;
	}
	
	@Autowired
	public void setOrderDAO(OrdersDAO odao) {
		this.odao = odao;
	}
	

	@Transactional
	public List<ProductDetails> getAllProds() {
		System.out.println("in service");
		return pmdao.getAllProducts();
	}


	public List<ProductDetails> getSelectProduct(String searchVal) {
		System.out.println(searchVal);
		return pmdao.getProductRows(searchVal);
	}


	public boolean updateProduct(int onHandQty, int productID, String productName) {
		// TODO Auto-generated method stub
		JsonResponse resp= new JsonResponse("SUCCESS");
		int qty = pmdao.getQty(productID);
		System.out.println("on hand table is:"+ qty);
		System.out.println("ordered is:"+onHandQty);
		if(qty > onHandQty) {
			qty -=onHandQty;
			pmdao.updateQty(qty,productID);
			System.out.println("calling the order insert................");
			odao.insertOrder(qty,productID);
			return true;
		}
		else {
			System.out.println("Order Creation Failed");
			resp.setStatus("error");
			return false;
		}
		
	}


	public int getOrderId() {
		return odao.getOrderId();
	}
	

}
