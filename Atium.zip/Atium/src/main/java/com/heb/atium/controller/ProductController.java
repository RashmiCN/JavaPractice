package com.heb.atium.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.ResponseBody;

import com.heb.atium.dao.ProductMasterDAO;
import com.heb.atium.model.ProductDetails;
import com.heb.atium.service.ProductService;
@Controller
public class ProductController {
	private ProductService productService;

	@Autowired
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}
	
	@GetMapping(value="/index")
	public String showProducts(Model model) {
		System.out.println("hey");
		 model.addAttribute("product", productService.getAllProds());
	     return "index";
	 	}	
	@RequestMapping(value = "atium/selectprod", method=RequestMethod.POST)
	 public String submit(@RequestParam("searchVal")String searchVal ,Model model) {
		 model.addAttribute("product", productService.getSelectProduct(searchVal));
	     return "index";
	 	}
	
	@RequestMapping(value="product/update",method=RequestMethod.POST)
//	@PostMapping("atium/product/update")
	@ResponseBody
	
    public JsonResponse updateProduct(@RequestBody ProductDetails product) {
		System.out.println("Ok working on update");
		JsonResponse response = new JsonResponse("SUCCESS");
		boolean worked =productService.updateProduct(product.getOnHandQty(),product.getProductID(),product.getProductName());
		
       if(worked) {
       	response.setStatus("SUCCESS");
       	int id = productService.getOrderId();
       	System.out.println("success id " + id);
       	response.setOrderid(id);
       	System.out.println(id);
    	response.setStatus("SUCCESS");
       	 }
       else {
       	response.setStatus("FAILURE");
       	 }
    	 System.out.println(response.getStatus());
    	 System.out.println(response.getOrderid());
    	 return response;
		 
    	}
}
