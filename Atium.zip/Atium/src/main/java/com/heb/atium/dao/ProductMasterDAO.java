package com.heb.atium.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.heb.atium.model.*;

@Component
public class ProductMasterDAO {

	private static final String GET_ALL_PRODUCT_QUERY =
			"select * from product_master where on_hand_qty > 0 ";
	private static final String GET_PRODUCT_QUERY =
			"select * from product_master where prod_id = ? ";
	private static final String GET_SELECTED_PRODUCT_QUERY =
			"select * from product_master where upper(prod_name) like upper(?) and on_hand_qty > 0";
	private static final String GET_QTY_OF_PROD_QUERY =
			"select on_hand_qty from product_master where prod_id = ?";
	private static final String GET_ON_ORD_OF_PROD_QUERY =
			"select on_order_qty from product_master where prod_id = ?";
	private static final String UPDATE_QTY_FOR_PROD = 
			"update product_master set on_hand_qty = ? , on_order_qty = ? where prod_id = ?";
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	@Autowired
	public ProductMasterDAO(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public List<ProductDetails> getAllProducts() {
//		System.out.println("in get all prods");
//		System.out.println(GET_ALL_PRODUCT_QUERY);
//		jdbcTemplate.execute(GET_ALL_PRODUCT_QUERY);
		List<ProductDetails> proddtl = jdbcTemplate.query(GET_ALL_PRODUCT_QUERY,new ProductMapper());
		if(proddtl.isEmpty()) {
			System.out.println("hey im getting null");
		}
		return proddtl;
	}
	
	public ProductDetails getProduct(int productID) {
		System.out.println("geting product :" + productID);
		System.out.println(productID);
		ProductDetails proddtl = (ProductDetails)jdbcTemplate.queryForObject(GET_PRODUCT_QUERY, new Object [] {productID}, new ProductMapper());
		System.out.println(proddtl);
		return proddtl;
	}
	
	public List<ProductDetails> getProductRows(String searchVal) {
//		System.out.println("in select prod per match");
		List<ProductDetails> prodsel = jdbcTemplate.query(GET_SELECTED_PRODUCT_QUERY,new String[] {"%"+ searchVal + "%"},new ProductMapper());
		if(prodsel.isEmpty()) {
			System.out.println("hey im getting null for selected prod");
		}
		return prodsel;
	}
	public boolean updateQty(int qty, int productID) {
		System.out.println("updating the product");
		int on_order =(int) jdbcTemplate.queryForObject(GET_ON_ORD_OF_PROD_QUERY,new Object[] {productID}, Integer.class);;
		on_order += qty;
		System.out.println("qty is " + qty);
		System.out.println("on order : "+ on_order);
		System.out.println("prod_id :" + productID);
		return jdbcTemplate.update(UPDATE_QTY_FOR_PROD,qty,on_order,productID) > 0 ;		
	}
	public int getQty(int productID) {
		// TODO Auto-generated method stub
		int prod_on_hand =(int) jdbcTemplate.queryForObject(GET_QTY_OF_PROD_QUERY,new Object[] {productID}, Integer.class);
		return prod_on_hand;
	}
	

}
