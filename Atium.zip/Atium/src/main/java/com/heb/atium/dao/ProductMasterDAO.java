package com.heb.atium.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.heb.atium.model.*;

@Component
public class ProductMasterDAO {

	private static final String GET_ALL_PRODUCT_QUERY =
			"select * from product_master ";
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	@Autowired
	public ProductMasterDAO(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public List<ProductDetails> getAllProducts() {
		System.out.println("in get all prods");
		System.out.println(GET_ALL_PRODUCT_QUERY);
		jdbcTemplate.execute(GET_ALL_PRODUCT_QUERY);
		List<ProductDetails> proddtl = jdbcTemplate.query(GET_ALL_PRODUCT_QUERY,new ProductMapper());
		if(proddtl.isEmpty()) {
			System.out.println("hey im getting null");
		}
		return proddtl;
	}
	

}
