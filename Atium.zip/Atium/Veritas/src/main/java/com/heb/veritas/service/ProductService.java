package com.heb.veritas.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.heb.veritas.dao.ProductMasterDAO;
import com.heb.veritas.model.*;

@Service
public class ProductService {
	private ProductMasterDAO prodDAO;

	@Transactional
	public List<ProductDetails> getAllProds() {
		return prodDAO.getAllProducts();
	}
	
	public static void main(String[] args) {
		ProductService psrev = new ProductService();
		for(ProductDetails pd :psrev.getAllProds()) {
			System.out.println(pd);
		}
	}
}
