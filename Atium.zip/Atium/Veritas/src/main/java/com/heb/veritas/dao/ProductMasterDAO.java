package com.heb.veritas.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.heb.veritas.model.*;


public class ProductMasterDAO {

	private static final String GET_ALL_PRODUCT_QUERY =
			"select prod_id,prod_name,manf_name,price,rating,on_hand_qty,on_order_qty " + 
			"from product_master where on_hand_qty > 0;";
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	@Autowired
	public ProductMasterDAO(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public List<ProductDetails> getAllProducts() {
		System.out.println("in get all prods");
		System.out.println(GET_ALL_PRODUCT_QUERY);
		
		return jdbcTemplate.query(GET_ALL_PRODUCT_QUERY, new ProductMapper());
	}
	
	public ProductMasterDAO() {
		super();
	}

	public static void main(String[] args) {
		ProductMasterDAO pmdao = new ProductMasterDAO();
		List<ProductDetails> pdtl = new ArrayList<ProductDetails>();
		for(ProductDetails pd : pmdao.getAllProducts()) {
			pdtl.add(pd);
			System.out.println(pd);
		}
	}
}
