package com.heb.atium.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.ResponseBody;

import com.heb.atium.service.ProductService;
@Controller
public class ProductController {
	private ProductService productService;

	@Autowired
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}
	
	@RequestMapping(value="/index",method=RequestMethod.POST)
	public String submit(Model model) {
		 model.addAttribute("product", productService.getAllProds());
	     return "index";
	 	}
//	@RequestMapping(value = "ecommerceweb3/product/selectprod", method=RequestMethod.POST)
//	 public String submit(@RequestParam("searchVal")String searchVal ,Model model) {
//		 model.addAttribute("product", productService.getSelectProduct(searchVal));
//	     return "header";
//	 	}
//	@GetMapping("/employee/list")
//	public String showEmployeesList(Model model) {
//		model.addAttribute("employees", employeeService.getAllEmployees());
//		return "emplist";
//	}
//	

}
