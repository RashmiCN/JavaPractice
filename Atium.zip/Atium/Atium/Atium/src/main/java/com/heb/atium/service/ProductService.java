package com.heb.atium.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.heb.atium.model.*;
import com.heb.atium.dao.ProductMasterDAO;

@Service
public class ProductService {
	private ProductMasterDAO prodDAO;

	public ProductService() {
		super();
	}

	@Transactional
	public List<ProductDetails> getAllProds() {
		return prodDAO.getAllProducts();
	}
	
	public static void main(String[] args) {
		ProductService psrev = new ProductService();
		for(ProductDetails pd :psrev.getAllProds()) {
			System.out.println(pd);
		}
	}
}
