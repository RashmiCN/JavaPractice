package com.heb.atium.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.heb.atium.dao.ProductMasterDAO;
import com.heb.atium.exception.OrderManagementException;
/**
 * Servlet implementation class ProdList
 */
@WebServlet("/ProdList")
public class ProdList extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private ProductMasterDAO prdDao;
    
    public ProdList() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProductMasterDAO pmd = new ProductMasterDAO();
		try {
			request.setAttribute("products", pmd.getAllProducts());
		} catch (Exception e) {
			request.setAttribute("message", e.getMessage());
		}
		RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
