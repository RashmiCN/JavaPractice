package com.heb.veritas.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.heb.veritas.model.ProductDetails;

public class ProductMapper implements RowMapper<ProductDetails>{
	
	public ProductDetails mapRow(ResultSet resultSet, int i) throws SQLException {
		System.out.println("in row mapper");
		ProductDetails prodDetail = new ProductDetails();
		prodDetail.setProductID(resultSet.getInt(1));
		prodDetail.setProductName(resultSet.getString(2));
		prodDetail.setManufacturer(resultSet.getString(3));
		prodDetail.setPrice(resultSet.getFloat(4));
		prodDetail.setRating(resultSet.getFloat(5));
		prodDetail.setOnHandQty(resultSet.getInt(6));
		prodDetail.setOnOrderQty(resultSet.getInt(7));
		System.out.println(prodDetail);
		return prodDetail;
	}
}
