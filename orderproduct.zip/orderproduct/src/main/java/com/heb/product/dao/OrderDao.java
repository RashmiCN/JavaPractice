package com.heb.product.dao;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.heb.product.model.Order;

@Component
public class OrderDao{
	private JdbcTemplate jdbcTemplate;
	private static String ORDER_INSERT = "INSERT INTO ORDERS(prod_id,order_date,delivery_date) VALUES(?,?,?)";
	private static String MAX_ORDER_ID = "SELECT ORDER_ID FROM ORDERS WHERE PROD_ID  = 1";
	
	@Autowired
	public OrderDao(DataSource dataSource) {
		System.out.println("creating dao instance");
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	@Transactional
	public boolean placeOrder(Order order) {
		return jdbcTemplate.update(ORDER_INSERT,
				order.getProdId(),
				order.getOrderDate(),
				order.getDeliveryDate()) > 0;	
				
	}		
	@Transactional
	public Order geMaxOrder() {
		return  jdbcTemplate.queryForObject(
				MAX_ORDER_ID,  
				new OrderMapper());
    }
}//end of class
