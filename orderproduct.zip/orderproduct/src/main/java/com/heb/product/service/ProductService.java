package com.heb.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.heb.product.dao.ProductDao;
import com.heb.product.model.Product;

@Service
public class ProductService {
	private ProductDao productDao;
	
	@Autowired
	public void setProductDao(ProductDao productDao) {
		System.out.println("in setProductDao");
		this.productDao = productDao;
	}
	
	@Transactional
	public List<Product> getAllProducts(String prodName) {
		String name= "%" + prodName + "%";
		System.out.println("like: " + name);
		System.out.println("in getAllProducts");
		return productDao.getProducts(name);
	}
	
	@Transactional
	public Product getProduct(int prodId) {
		System.out.println("in getAllProduct");
		return  productDao.getProduct(prodId);
	}
}
