
package com.heb.product.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.heb.product.model.Product;
import com.heb.product.service.ProductService;

@Controller
public class SearchController {
       private ProductService productService;
       @Autowired
       public void setProductService(ProductService productService) {
              this.productService = productService;
       }    
       @RequestMapping("/home")
       public String showHomePage(){
              return "home";
       }

       @PostMapping("/productSearch")
       public String showProductList(Product product,Model model,HttpServletRequest request) {
    	      request.getSession().setAttribute("product", product);
    	      System.out.println("prodName: " + product.getProdName());
              model.addAttribute("products", productService.getAllProducts(product.getProdName()));
              return "productList";
       }
            
}

