package com.heb.product.service;

import java.util.Date;
import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.heb.product.dao.OrderDao;
import com.heb.product.dao.ProductDao;
import com.heb.product.model.Order;
import com.heb.product.model.Product;

@Service
public class OrderService {
	private OrderDao orderDao;
	private ProductDao productDao;
	
	@Autowired
	public void setOrderDao(OrderDao orderDao) {
		System.out.println("in orderDao");
		this.orderDao = orderDao;
	}
	@Autowired
	public void setProductDao(ProductDao productDao) {
		System.out.println("in setProductDao");
		this.productDao = productDao;
	}
	@Transactional
	public String placeOrder(int prodId, int orderedQty){	
		String orderMessage = null;
		int newProdQty = 0;
		Order order = new Order();
		Product product = productDao.getProduct(prodId);
		if (orderedQty < product.getProdQuantity()){
			System.out.println("order qty < prod quantity");
			order.setProdId(product.getProdId());
			//date things here
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			order.setOrderDate(c.getTime());
			c.add(Calendar.DATE, 3);
			order.setDeliveryDate(c.getTime());

			boolean orderPlaced = orderDao.placeOrder(order);
			newProdQty = product.getProdQuantity() - orderedQty;
			product.setProdQuantity(newProdQty);
			boolean updatedInventory = productDao.updateInvetory(product);
			if(orderPlaced && updatedInventory){
				orderMessage = "Order placed successfully for order id: ";		
			}
		}else{
			//throws error message here 
			orderMessage = "Product is Out of stock, we will notify you once its available";
		}
		
		
		return orderMessage;
	}
}
