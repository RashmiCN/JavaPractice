package com.heb.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.heb.product.model.Product;
import com.heb.product.service.ProductService;

@RestController
public class ProductListRestController {
    private ProductService productService;
    @Autowired
    public void setProductService(ProductService productService) {
           this.productService = productService;
    } 
	@RequestMapping("/rest/getProductList/{prodName}")
    public List<Product> showProductList(@PathVariable String prodName,Model model) {
           return productService.getAllProducts(prodName);
    }
}
