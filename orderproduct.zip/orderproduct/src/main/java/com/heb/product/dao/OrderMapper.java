package com.heb.product.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.heb.product.model.Order;

public class OrderMapper implements RowMapper<Order>{
    public Order mapRow(ResultSet rs, int i) throws SQLException {
    	Order order = new Order();
		order.setOrderId(rs.getInt("order_id"));		
	    return order;
	  }
}