package com.heb.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.heb.product.model.Order;
import com.heb.product.model.Product;
import com.heb.product.service.OrderService;
import com.heb.product.service.ProductService;

@Controller
public class OrderController {
	private OrderService orderService;
	
	@Autowired
	public void setOrderService(OrderService orderService) {
		this.orderService = orderService;
	}
	private ProductService productService;

	
	@Autowired
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}
	
	@RequestMapping("buyNow/get/{prodId}")
	public String showHomePage(@PathVariable int prodId,Model model){	
		  Order order = new Order();
		  model.addAttribute("product", productService.getProduct(prodId));
		  model.addAttribute("order", order);
		return "placeOrder";
	}

	@PostMapping("/orderNow")
	public String OrderPage(Product product, Order order,Model model){ 
		System.out.println("prod-id" +product.getProdId());
	//	int orderQty = Integer.parseInt(orderedQty);
		System.out.println("qty" + order.getOrderedQty());
		String message = orderService.placeOrder(product.getProdId(), order.getOrderedQty());
		model.addAttribute("message", message);
		return "order";
	}	
}
