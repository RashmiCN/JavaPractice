package com.heb.product.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.heb.product.model.Product;

public class ProductMapper implements RowMapper<Product>{
      public Product mapRow(ResultSet rs, int i) throws SQLException {
		Product product = new Product();	
		product.setProdId(rs.getInt("prod_id"));
		product.setProdName(rs.getString("prod_name"));
		product.setProdManufacturer(rs.getString("prod_manufacturer"));
		product.setProdPrice(rs.getDouble("prod_price"));
		product.setProdRating(rs.getFloat("prod_rating"));
		product.setProdQuantity(rs.getInt("prod_qty"));
	    return product;
	  }
}
