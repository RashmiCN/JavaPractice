package com.heb.product.model;

public class Product {
	private int prodId;
	private String prodName;
	private String prodManufacturer;
	private double prodPrice;
	private float prodRating;
	private int prodQuantity;
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getProdManufacturer() {
		return prodManufacturer;
	}
	public void setProdManufacturer(String prodManufacturer) {
		this.prodManufacturer = prodManufacturer;
	}
	public double getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(double prodPrice) {
		this.prodPrice = prodPrice;
	}
	public float getProdRating() {
		return prodRating;
	}
	public void setProdRating(float prodRating) {
		this.prodRating = prodRating;
	}
	public int getProdQuantity() {
		return prodQuantity;
	}
	public void setProdQuantity(int prodQuantity) {
		this.prodQuantity = prodQuantity;
	}	
}
