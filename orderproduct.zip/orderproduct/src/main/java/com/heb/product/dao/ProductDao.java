package com.heb.product.dao;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.heb.product.dao.ProductMapper;
import com.heb.product.model.Product;

@Component
public class ProductDao {
	public static final String productDao = null;
	private JdbcTemplate jdbcTemplate;
	//private static String PRODUCT_LIST = "select * from product where prod_manufacturer =  'samsung' ";
	private static String PRODUCT_LIST = "select * from product where prod_name like ? ";
	private static String PRODUCT_ONE = "select * from product where prod_id = ?";
	private static String UPDATE_PROD_RTY = "UPDATE PRODUCT SET PROD_QTY = ? WHERE PROD_ID = ?";
	
	
	@Autowired
	public ProductDao(DataSource dataSource) {
		System.out.println("creating dao instance");
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	@Transactional
	public List<Product> getProducts(String prodName) {
		return jdbcTemplate.query(
				PRODUCT_LIST, 
				new Object[] { prodName },
				new ProductMapper());
	}	
	@Transactional
	public Product getProduct(int prodId) {
		System.out.println("in getProudct:" + prodId);
		return  jdbcTemplate.queryForObject(
				PRODUCT_ONE,  
				new Object[] {prodId},
				new ProductMapper());
	}	
	@Transactional
	public boolean updateInvetory(Product product) {
		return jdbcTemplate.update(UPDATE_PROD_RTY ,
				product.getProdQuantity(),
				product.getProdId()
				) > 0;	
	}			
	
}//end of class
