function toRow(product) {
    var html = "";
    html += "<tr>";
    html += "    <td>" + product.prodName + "</td>";
    html += "    <td>" + product.prodManufacturer + "</td>";
    html += "    <td>" +product.prodPrice + "</td>";
    html += "    <td>" + product.prodRating + "</td>";
    html += "    <td><a href=''>Edit</a> <a href=''>Delete</a></td>";
    html += "</tr>";

    return html;
}

function tableHeader() {
    var html = "";
    html += "<table id='employees'>";
    html += "    <tr class='table-heading'>";
    html += "        <th>Product</td>";
    html += "        <th>Manufacturer</td>";
    html += "        <th>Price</td>";
    html += "        <th>Rating</td>";
    html += "        <th>Select Products</td>";
    html += "    </tr>";
    return html;
}

$(document).ready(function(){
	
	var prefix = "/orderproduct2"

    $.get(prefix + "/app/rest/product/list/sam", function(data, status) {
        var tableData = tableHeader();
        for (var i = 0; i < data.length; i++) {
            tableData += toRow(data[i]);
        }
        tableData += "</table>";
        $("#jsonProdList").append(tableData);
    });

    $("#saveRestBtn").click(function() {
       if ($("#name").val() == "") {
           $("#err-name").text("Name cannot be empty");
           return;
       } else {
           $("#err-name").text("");
       }
       
       $.ajax({
    	   type: "POST",
           url : prefix + "/app/rest/employee/update",
           data : $('form[name=employeeForm]').serialize(),
           success : function(res) {
        	   $(".success").text("Employee details saved successfully.");
           },
           error: function(xhr, status, error) {
        	   alert("Save failed.");
           }
        })
    });
});
