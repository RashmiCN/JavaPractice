package test;

public class Garbage {

}
