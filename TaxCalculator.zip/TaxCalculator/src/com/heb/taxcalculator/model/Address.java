// Class for the employee address details

package com.heb.taxcalculator.model;
public class Address{

//Declarations for the class
	private int id;
	private String addressLine1;
	private String addressLine2;			
	private String locality;
	private String city;
	private String pincode;


// constructor to initialize the id,age and string name

 	 public String getAddressLine1() {
		return addressLine1;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
		System.out.println("inside Addressline1");
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	Address(String[] employeeDetails){
		addressLine1 = employeeDetails[5];
		addressLine2 = employeeDetails[6];
		locality = employeeDetails[7];
		city = employeeDetails[8];
		pincode = employeeDetails[9];
	}
	
// Overloading the toString()  method to return the required values
	
	public Address() {
		// TODO Auto-generated constructor stub
	}

	public String toString(){
		StringBuilder builder = new StringBuilder();
		builder.append("AddressLine1 = ");
		builder.append(addressLine1);
		builder.append(";");
		builder.append("AddressLine2 = ");
		builder.append(addressLine2);
		builder.append(";");
		builder.append("Locality = ");
		builder.append(locality);
		builder.append(";");
		builder.append("City = ");
		builder.append(city);
		builder.append(";");
		builder.append("Pincode = ");
		builder.append(pincode);
		builder.append(";");
		return builder.toString();
	}
}
	