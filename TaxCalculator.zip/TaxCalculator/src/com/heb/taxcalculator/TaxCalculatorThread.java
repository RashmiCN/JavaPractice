package com.heb.taxcalculator;

import com.heb.taxcalculator.model.tax.AbstractIncomeTaxPay1	;
import com.heb.taxcalculator.model.Employee;


public class TaxCalculatorThread extends Thread{
    private AbstractIncomeTaxPay1 taxCalculator;
    private Employee employee;
    private static long counter = 0;

    public TaxCalculatorThread(AbstractIncomeTaxPay1 taxCalculator,
                                Employee employee){
        this.taxCalculator=taxCalculator;
        this.employee=employee;
    }
    
    public void run(){
        employee.setTaxAmount((float)taxCalculator.calculateTax());

        //Forces execution of thread to be synchronized
        synchronized(TaxCalculatorThread.class){
            System.out.print(++counter + " ");
        }        
    }
}
