
package com.heb.taxcalculator.dao;

import com.heb.taxcalculator.model.Employee;

import java.util.List;



interface TaxCalculatorFileReader{
//	public void openFile(String fileNamewithPath);
//	public Employee readLine();
//	public void closeFile();

	public List<Employee> readAll(String fileNameWithPath);
	
	
}
	
	