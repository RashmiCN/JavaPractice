
package com.heb.taxcalculator.dao;

import com.heb.taxcalculator.model.Employee;

import java.util.List;

import java.io.FileReader;

import java.io.BufferedReader;

import java.util.ArrayList;

import java.io.IOException;

public class TaxCalculatorCsvFileReader implements 
									TaxCalculatorFileReader {
									
	
	public List<Employee> readAll(String fileNameWithPath){
		
		List<Employee> employees = new ArrayList<Employee>();
		BufferedReader reader = null;
		try {
		
			reader = new BufferedReader(new FileReader(fileNameWithPath));
			String line = reader.readLine();
			
		while(line !=null) {
			
//			System.out.println(line);
			Employee e = new Employee(line);
			employees.add(e);
			line = reader.readLine();
		}
		
		reader.close();
		} catch(IOException exception) {
			exception.printStackTrace();
		//System.out.println("Operation failed");
			System.out.println(exception.getMessage());
		} finally {
			if(reader != null){
				try{
					reader.close();
				} catch (IOException e){
					e.printStackTrace();
				}
			}
//			System.out.println("Finally");
			
		}
		return employees;
	}
		
}