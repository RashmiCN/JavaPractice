$(document).ready(function(){
	 $(".btn").click(function() {
		 
		 if($(this).closest("tr").find('.grid-item-6').val() == 0)
			 {
			 alert("Please enter valid quanity");
			 return;
			 }
		 var data = {}
		 data["productId"] = $(this).closest("tr").find('.grid-item-1').val();
		 data["productName"] = $(this).closest("tr").find('.grid-item-2').val();
		 data["manufacturer"] = $(this).closest("tr").find('.grid-item-3').val();
		 data["price"] = $(this).closest("tr").find('.grid-item-4').val();
		 data["rating"]  =  $(this).closest("tr").find('.grid-item-5').val();
		 data["quantity"]  = $(this).closest("tr").find('.grid-item-6').val();
		  $.ajax({
	         type: "POST",
	           url :"/ecommerceweb3/product/update",
	           data : JSON.stringify(data),
	           contentType: "application/json",
	           Accept: "application/json",
	           success : function(response) {
	        	    if(response.status=="SUCCESS")
	        		   {
	        	   			alert("Thanks for placing the order  Order_ID : " + response.orderid);
	        		   }
	        	   else
	        		   {
	        		   		alert("Order not placed , Sufficient quantity not available in inventory");
	        		   }
	        	    document.getElementById("productform").reset();
	           },
	           error: function(xhr, status, error) {
	               alert("Save failed.");
	           }
	           

	        })

	    });

	});
