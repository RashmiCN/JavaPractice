package com.heb.ecommerce.controller;

public class JsonResponse {

      private String status;
      private int orderid;

  	public JsonResponse() {

  		}

      
    public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

      public JsonResponse(String status) {
            super();
            this.status = status;

      }

      public String getStatus() {
            return status;

      }
      public void setStatus(String status) {
            this.status = status;

      }

	@Override
	public String toString() {
		return "JsonResponse [status=" + status + "]";
	}

     

}