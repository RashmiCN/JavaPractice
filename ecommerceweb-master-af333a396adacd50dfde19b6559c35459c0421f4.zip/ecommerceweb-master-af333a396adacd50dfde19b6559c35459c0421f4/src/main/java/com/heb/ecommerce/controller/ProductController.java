package com.heb.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.heb.ecommerce.model.Product;
import com.heb.ecommerce.service.ProductService;

@Controller
public class ProductController {
	private ProductService productService;

	@Autowired
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}
	
	 @RequestMapping(value="product/update",method=RequestMethod.POST)
	 @ResponseBody
	
     public JsonResponse updateProduct(@RequestBody Product product) {
		JsonResponse response = new JsonResponse("SUCCESS");
		boolean a =productService.updateProduct(product.getQuantity(),product.getProductId(),product.getProductName());
		
        if(a) {
        	response.setStatus("SUCCESS");
        	int id = productService.getOrderId();
        	response.setOrderid(id);
        	System.out.println(id);
        	 }
        else {
        	response.setStatus("FAILURE");
        	 }
     	 System.out.println(response.getStatus());
     	 System.out.println(response.getOrderid());
     	 return response;
		 
     	}
	 
	 @RequestMapping(value = "ecommerceweb3/product/selectprod", method=RequestMethod.POST)
	 public String submit(@RequestParam("searchVal")String searchVal ,Model model) {
		 model.addAttribute("product", productService.getSelectProduct(searchVal));
	     return "header";
	 	}
	 
	}
