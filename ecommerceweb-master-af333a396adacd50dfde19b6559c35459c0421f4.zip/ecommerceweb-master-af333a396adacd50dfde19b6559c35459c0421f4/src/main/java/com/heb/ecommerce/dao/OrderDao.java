package com.heb.ecommerce.dao;

import java.util.Date;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.heb.ecommerce.model.OrderDetails;

@Component
public class OrderDao {
	
	 private static final String INSERT_STRING =  "insert into orderdetails (orderdate,product_name,deliverdate)" +"VALUES(?,?,?)";
	 
	 private static final String GET_SELECT_ORDER_QUERY = "select max(order_id) from orderdetails" ;
	
	
	private JdbcTemplate template;
	
	 public OrderDao() {
			super();
			// TODO Auto-generated constructor stub
		}
	 
	@Autowired
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	@Autowired
	public OrderDao(DataSource dataSource) {
                    template = new JdbcTemplate(dataSource);

    }

	
	public boolean insertOrder(int prodId,String productName){
		
		OrderDetails order = new OrderDetails();
		Date sqlDate = order.getOrderDate();
		Date futureDate = order.getDeliveryDate();
		 
		Object[] params = {
				sqlDate,productName,futureDate
		};
		
		template.update(INSERT_STRING, params);
		
		return true;
		
		};
		
		public int getOrderIdRowMapper(){
			
			int orderid = (int) template.queryForObject(GET_SELECT_ORDER_QUERY,new Object [] {} ,Integer.class);
			return orderid;

		};

}
