package com.heb.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.heb.ecommerce.controller.JsonResponse;
import com.heb.ecommerce.dao.OrderDao;
import com.heb.ecommerce.dao.ProductDao;
import com.heb.ecommerce.model.Product;

@Service
public class ProductService {
	
	private ProductDao productDao;
	private OrderDao orderDao;
	
	public ProductService() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Autowired
	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	@Autowired
	public void setOrderDao(OrderDao orderDao) {
		this.orderDao = orderDao;
	}


	@Transactional
	public List<Product>getAllProduct(){
		return productDao.getAllProductRow();
	}
	
	@Transactional
	public boolean updateProduct(int quantity,int productid,String productName) {
		
		 JsonResponse response = new JsonResponse("SUCCESS");
		 int qty = productDao.getQuantity(productid);
		if(qty >= quantity)
		{   
			qty -= quantity;
			productDao.updateProduct(qty,productid);
			orderDao.insertOrder(productid,productName);
			return true;
		}
		else
		{
			System.out.println("Update failed");
			response.setStatus("error");
			return false;
		}
	}
	
	@Transactional
	public List<Product>getSelectProduct(String searchVal){
		System.out.println(searchVal);
		return productDao.getSelectProductRow(searchVal);
	}
	
	@Transactional
	public int getOrderId(){
		return orderDao.getOrderIdRowMapper();
	}
	

}
