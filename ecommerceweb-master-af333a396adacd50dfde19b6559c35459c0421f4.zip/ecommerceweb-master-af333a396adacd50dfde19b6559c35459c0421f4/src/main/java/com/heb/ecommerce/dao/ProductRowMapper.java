package com.heb.ecommerce.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.jsp.jstl.sql.Result;

import org.springframework.jdbc.core.RowMapper;

import com.heb.ecommerce.model.Product;

public class ProductRowMapper implements RowMapper<Product>{
	
	public Product mapRow(ResultSet rs,int i) throws SQLException {
		Product p = new Product();
		p.setProductId(rs.getInt(1));
		p.setProductName(rs.getString(2));
		p.setManufacturer(rs.getString(3));
		p.setPrice(rs.getInt(4));
		p.setRating(rs.getInt(5));
		p.setQuantity(rs.getInt(6));
		return p;
	}

}
