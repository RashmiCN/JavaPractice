package com.heb.ecommerce.dao;

import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.sql.SQLException; 
import javax.sql.DataSource;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import com.heb.ecommerce.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;  

@Component
public class ProductDao {

	 private static final String GET_ALL_PRODUCT_QUERY = " select * from product";
	 
	 private static final String GET_SELECT_PRODUCT_QUERY = " select * from product where upper(PRODUCTNAME) like upper(?) and quantity >0 ";
	 
	 private static final String UPDATE_PRODUCT_QUERY = "update product set quantity = ? where productid = ?";
	 
	 private static final String GET_QUANTITY_QUERY = "select quantity from product where productid = ?";
	 
		 
	 private JdbcTemplate template;
	 
	 public ProductDao() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Autowired
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public ProductDao(DataSource dataSource) {
                    template = new JdbcTemplate(dataSource);

    }

	public List<Product> getAllProductRow(){
	
		return template.query(GET_ALL_PRODUCT_QUERY,new ProductRowMapper());

	}
	
	public boolean updateProduct(int quantity,int productid){
		
		return template.update(UPDATE_PRODUCT_QUERY,quantity,productid) > 0 ;
		
	}
	
	public List<Product> getSelectProductRow(String searchVal){
		
		return template.query(GET_SELECT_PRODUCT_QUERY,new String[] {"%" + searchVal +"%"},new ProductRowMapper());
		
	}
	
	
	public int getQuantity(int productid){
		int qty = (int) template.queryForObject(GET_QUANTITY_QUERY,new Object [] {productid},Integer.class);
		return qty;	
	};
	
	

	}
			


