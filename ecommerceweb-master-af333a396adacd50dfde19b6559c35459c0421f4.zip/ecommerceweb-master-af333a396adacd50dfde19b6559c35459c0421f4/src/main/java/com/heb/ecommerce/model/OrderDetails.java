package com.heb.ecommerce.model;

import java.util.Date;
import java.util.Calendar;

public class OrderDetails {
	
	int orderid;
	String productName;
	Date orderDate ;
	Date deliveryDate;
	
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Date getOrderDate() {
		 java.util.Date date = new java.util.Date();
		 long t = date.getTime();
		 java.sql.Date  orderDate= new java.sql.Date(t);
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
		
	}
	public Date getDeliveryDate() {
		Date date1 = new Date();
		 Calendar c = Calendar.getInstance(); 
		 c.setTime(date1); 
		 c.add(Calendar.DATE,3);
		 date1 = c.getTime();
		 long t1 = date1.getTime();
		 Date deliveryDate = new java.sql.Date(t1);
		 return deliveryDate;
	}
	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
		 
	}


}
